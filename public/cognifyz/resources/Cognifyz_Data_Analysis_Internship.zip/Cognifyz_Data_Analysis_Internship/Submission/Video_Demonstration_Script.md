# Video Demonstration Script - Cognifyz Data Analysis Internship

**Target length:** 3 to 4 minutes (LinkedIn works best under 5 minutes). **Speak in your own words** - the lines below are a guide, not a script to read robotically.

## Suggested video sequence

| Time | On screen | What to say |
|---|---|---|
| 0:00-0:15 | Title slide (Presentation, slide 1) | "Hi, I'm Pratham. This is my Data Analysis internship project for Cognifyz Technologies, using a restaurant dataset of 9,551 restaurants across 15 countries." |
| 0:15-0:40 | Project folder in your file explorer / VS Code | "I completed all three levels. Each level has its own Python script, a Jupyter notebook, and task folders with tables and charts." |
| 0:40-1:10 | Slide 6 (cleaning) or `Level_1_Analysis.ipynb` top cells | "First I cleaned the data: no duplicates, 9 missing cuisines, and ratings of 0 that actually mean 'not rated', so I excluded them from rating averages." |
| 1:10-1:50 | Level 1 slides 7-10 (cuisines, cities, price range, delivery) | "North Indian, Chinese and Fast Food are the top cuisines. New Delhi has the most restaurants. 79% of restaurants are in the two lowest price ranges, and about 26% offer online delivery." |
| 1:50-2:35 | Level 2 slides 11-14, then open `L2_T3_interactive_map.html` in a browser and zoom into Delhi | "Level 2 covers rating distribution, cuisine combinations, geography and chains. This interactive Folium map has clustered markers coloured by rating, a heat map and hotspot layers." |
| 2:35-3:20 | Level 3 slides 15-17 | "Level 3: the dataset has no review text, so I documented that task as blocked instead of inventing data. Votes correlate positively with ratings, and table booking rises with price while online delivery peaks at mid prices." |
| 3:20-3:45 | Slide 20 (completion matrix) then slide 21 | "Ten of eleven tasks are completed and verified; one is blocked by missing data. Thank you to Cognifyz Technologies for this opportunity." |
| 3:45-4:00 | End card | Say the hashtags or show them on screen. |

## Screen recording instructions

1. Use any recorder: Windows **Xbox Game Bar (Win + G)**, macOS **QuickTime > New Screen Recording**, or **OBS Studio** (free).
2. Set the screen to 1920x1080, close unrelated windows and notifications, and zoom the browser/notebook to about 125% so text is readable on a phone.
3. Open these in advance, in this order: the presentation, the project folder, `Level_1_Analysis.ipynb`, the interactive map HTML (needs internet for map tiles).
4. Record voice with a headset microphone in a quiet room. Do one short test recording first.
5. Trim mistakes in a basic editor (Clipchamp, iMovie, CapCut). Export MP4, 1080p.
6. Add captions if possible - many LinkedIn viewers watch muted.
7. Upload to LinkedIn natively (not a YouTube link), and tag **Cognifyz Technologies** in the post.

## Tips
- Show real outputs (charts, the map) rather than reading slides word for word.
- Be honest about the missing-review limitation - it shows analytical maturity.
- Mention one business insight you find most interesting (for example: premium restaurants are booking-led, mid-price restaurants are delivery-led).
