# LinkedIn Post (DRAFT - not published)

> This is a draft for you to review, edit and post yourself. Nothing has been posted or submitted on your behalf.
> Remember to attach your demonstration video and tag the **Cognifyz Technologies** company page.

---

I have completed my **Data Analysis Internship at Cognifyz Technologies**, and I'm excited to share what I built.

I analysed a dataset of **9,551 restaurants across 15 countries** and completed **all three levels** of the internship (Level 1 basic, Level 2 intermediate, Level 3 advanced), using Python, pandas, Matplotlib, Folium and scikit-learn.

What I explored:
- **Top cuisines and cities:** North Indian, Chinese and Fast Food lead; New Delhi alone holds 57% of the records.
- **Price and services:** table booking rises with price tier, while online delivery peaks at mid-price restaurants.
- **Ratings and votes:** better-rated restaurants collect far more votes (Spearman correlation 0.68).
- **Geography:** an interactive Folium map plus DBSCAN clustering to find restaurant hotspots in Delhi NCR.
- **Chains:** the biggest chains are not the best rated, while Barbeque Nation stands out on both rating and popularity.

One honest lesson: the dataset had no review text, so I documented that task as blocked instead of inventing results. Clean data work includes knowing what the data cannot tell you.

Thank you to **Cognifyz Technologies** for the opportunity and the learning experience!

#cognifyztechnologies #cognifyz #cognifyztech #DataAnalysis #Python #DataVisualization #Pandas #Internship #DataScience #EDA

---

## Optional extras
- Add a link to your GitHub repository: https://github.com/prathampanchmukh1234-maker (once the project is uploaded there).
- Shorter version (if you prefer): "Completed my Data Analysis internship at Cognifyz Technologies - 3 levels, 11 tasks, 9,551 restaurants analysed in Python. Video below! #cognifyztechnologies #cognifyz #cognifyztech"
