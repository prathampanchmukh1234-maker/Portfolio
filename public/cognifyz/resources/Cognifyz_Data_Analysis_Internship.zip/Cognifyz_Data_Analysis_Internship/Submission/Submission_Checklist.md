# Submission Checklist - Cognifyz Data Analysis Internship

Status key: [x] done in the project files, [ ] still needs YOU to do it. Nothing below has been posted or submitted for you.

## Project deliverables (prepared)
- [x] Level 1 (4 tasks): script, executed notebook, tables, charts
- [x] Level 2 (4 tasks): script, executed notebook, tables, charts, interactive Folium map
- [x] Level 3 (3 tasks): script, executed notebook, tables, charts (Task 1 documented as Blocked - Missing Data)
- [x] Reports: Level 1, Level 2, Level 3 and Final Internship Report (PDF)
- [x] Presentation: Internship_Presentation.pptx (21 slides)
- [x] README with run instructions
- [x] Completion matrix (Reports/results/completion_matrix.json and slide 20)

## Actions required from you
- [ ] Re-run the analysis once on your own machine (see README) to confirm it works for you
- [ ] Open the interactive map in a browser (needs internet for tiles) and rehearse zooming into Delhi
- [ ] Review the LinkedIn post draft and edit it in your own words
- [ ] Record the demonstration video (see Video_Demonstration_Script.md)
- [ ] Upload the video to LinkedIn, tag **Cognifyz Technologies**, and include #cognifyztechnologies #cognifyz #cognifyztech
- [ ] Make your GitHub repository public (optional) and add its link to the post
- [ ] **Wait for the submission form:** the Cognifyz internship document says the submission form will be shared later. When you receive it, submit your LinkedIn post link (and any other fields it asks for)
- [ ] Keep a copy of your submitted form / confirmation

## Honest notes to keep in mind
- The dataset contains no review text, so Level 3 Task 1 could not be completed with real data. If Cognifyz provides review data, run `Level_3_Advanced_Analysis/Task_1_Restaurant_Reviews/review_analysis_template.py`.
- The Cognifyz programme officially requires two levels; this project covers all three.
