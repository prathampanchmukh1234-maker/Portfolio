"""
build_reports.py - builds the four PDF reports from the REAL analysis outputs.

Inputs : Reports/results/*.json, task-folder CSV tables, findings.md files, Visualizations/*.png
Outputs: Level_1_Report.pdf, Level_2_Report.pdf, Level_3_Report.pdf, Final_Internship_Report.pdf (this folder)
Run after the three Level_N_Analysis.py scripts:  python Reports/build_reports.py
"""
import json
from pathlib import Path

import pandas as pd
from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "Reports" / "results"
OUT = ROOT / "Reports"
AUTHOR = "Pratham"
DATE = "November 2026"
BLUE, INK, GREY = colors.HexColor("#1a4f93"), colors.HexColor("#0b0b0b"), colors.HexColor("#52514e")

for name, f in (("DV", "DejaVuSans.ttf"), ("DV-B", "DejaVuSans-Bold.ttf")):
    pdfmetrics.registerFont(TTFont(name, f"/usr/share/fonts/truetype/dejavu/{f}"))
S = getSampleStyleSheet()
ST = {
    "title": ParagraphStyle("t", fontName="DV-B", fontSize=26, leading=32, textColor=BLUE, spaceAfter=10),
    "sub": ParagraphStyle("s", fontName="DV", fontSize=13, leading=18, textColor=GREY, spaceAfter=6),
    "h1": ParagraphStyle("h1", fontName="DV-B", fontSize=16, leading=20, textColor=BLUE, spaceBefore=14, spaceAfter=8),
    "h2": ParagraphStyle("h2", fontName="DV-B", fontSize=12.5, leading=16, textColor=INK, spaceBefore=10, spaceAfter=5),
    "body": ParagraphStyle("b", fontName="DV", fontSize=9.3, leading=14, textColor=INK, spaceAfter=5, alignment=TA_LEFT),
    "bullet": ParagraphStyle("bl", fontName="DV", fontSize=9.3, leading=13.5, leftIndent=14, bulletIndent=2, spaceAfter=3),
    "cap": ParagraphStyle("c", fontName="DV", fontSize=8, leading=10.5, textColor=GREY, spaceAfter=8),
    "cell": ParagraphStyle("ce", fontName="DV", fontSize=7.6, leading=9.6),
    "cellh": ParagraphStyle("ch", fontName="DV-B", fontSize=7.6, leading=9.6, textColor=colors.white),
}
esc = lambda s: str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def load(level):
    return json.loads((RES / f"level_{level}_results.json").read_text(encoding="utf-8"))


CLEAN = json.loads((RES / "cleaning_log.json").read_text(encoding="utf-8"))
R = {1: load(1), 2: load(2), 3: load(3)}


# ---------------------------------------------------------------- flowable helpers
def P(t, st="body"): return Paragraph(t, ST[st])
def bullets(items): return [Paragraph(esc(i), ST["bullet"], bulletText="•") for i in items if i]


def fmt(v):
    if isinstance(v, float):
        if pd.isna(v): return ""
        return f"{v:,.2f}" if abs(v) < 1e5 else f"{v:,.0f}"
    if isinstance(v, int): return f"{v:,}"
    return str(v)


def table(df, caption=None, widths=None):
    data = [[Paragraph(esc(c), ST["cellh"]) for c in df.columns]]
    for row in df.itertuples(index=False):
        data.append([Paragraph(esc(fmt(v)), ST["cell"]) for v in row])
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), BLUE), ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f1f4f9")]),
                           ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#d0d6df")), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                           ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    out = [t]
    if caption: out.append(P(esc(caption), "cap"))
    return out + [Spacer(1, 6)]


def csv_table(rel, caption, cols=None, rename=None, rows=10, round_=None):
    df = pd.read_csv(ROOT / rel)
    if cols: df = df[cols]
    df = df.head(rows)
    if rename: df = df.rename(columns=rename)
    return table(df, caption)


def figure(name, level, caption, width_cm=16.5):
    path = ROOT / "Visualizations" / f"Level_{level}" / name
    w, h = PILImage.open(path).size
    width = width_cm * cm
    return KeepTogether([Image(str(path), width=width, height=width * h / w), P(esc(caption), "cap")])


def findings(level, task_folder):
    return [l[2:].strip() for l in (ROOT / task_folder / "findings.md").read_text(encoding="utf-8").splitlines() if l.startswith("- ")]


def footer(canvas, doc):
    canvas.saveState(); canvas.setFont("DV", 7.5); canvas.setFillColor(GREY)
    canvas.drawString(2 * cm, 1.2 * cm, "Cognifyz Technologies - Data Analysis Internship")
    canvas.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"Page {doc.page}")
    canvas.restoreState()


# ---------------------------------------------------------------- task catalogue (content comes from the results)
def L1_tasks():
    r1, r2, r3, r4 = (R[1][f"task{i}"] for i in range(1, 5))
    t3 = r3["table"]
    return [
        dict(key="L1T1", folder="Level_1_Basic_Analysis/Task_1_Top_Cuisines", title="Task 1 - Top Cuisines",
             statement="Determine the top three most common cuisines in the dataset and calculate the percentage of restaurants that serve each of them.",
             method="The multi-value Cuisines column was split into individual cuisines; each restaurant was counted once per cuisine it lists. Percentages use the 9,542 restaurants with cuisine information as the base (shares sum to more than 100% because restaurants list several cuisines).",
             code="pandas str.split + explode, groupby nunique on Restaurant ID, horizontal bar chart with the top three highlighted.",
             tables=[lambda: csv_table("Level_1_Basic_Analysis/Task_1_Top_Cuisines/cuisine_counts_all.csv", "Top 10 cuisines (percentages are shares of restaurants with cuisine information).", rows=10)],
             charts=[("L1_T1_top_cuisines.png", 1, "Figure: top 10 cuisines, top three highlighted.")],
             insights=[f"A menu built around {r1['top3'][0]['Cuisine']}, {r1['top3'][1]['Cuisine']} and {r1['top3'][2]['Cuisine']} would cover the cuisines most often listed; these three appear in {r1['top3'][0]['% of restaurants with cuisine info']:.0f}%, {r1['top3'][1]['% of restaurants with cuisine info']:.0f}% and {r1['top3'][2]['% of restaurants with cuisine info']:.0f}% of restaurants.",
                       f"With {r1['distinct']} distinct cuisines but heavy concentration on a few, niche cuisines represent low-competition positioning opportunities (within this dataset's North India-heavy coverage)."]),
        dict(key="L1T2", folder="Level_1_Basic_Analysis/Task_2_City_Analysis", title="Task 2 - City Analysis",
             statement="Identify the city with the highest number of restaurants, calculate the average rating per city and determine the city with the highest average rating.",
             method="Restaurants were grouped by city. Ratings of 0 mean 'Not rated' and were excluded from averages. Because tiny samples distort rankings, the highest average rating is reported both unfiltered and for cities with at least 20 rated restaurants.",
             code="groupby(City).agg(count, mean of Rating), threshold filter, Spearman correlation between size and rating, three charts.",
             tables=[lambda: csv_table("Level_1_Basic_Analysis/Task_2_City_Analysis/city_summary_all.csv", "Top 10 cities by number of restaurants.", rows=10),
                     lambda: csv_table("Level_1_Basic_Analysis/Task_2_City_Analysis/city_avg_rating_min20_rated.csv", "Highest-rated cities with at least 20 rated restaurants.", rows=8)],
             charts=[("L1_T2_restaurants_by_city.png", 1, "Figure: restaurant counts, top 10 cities."), ("L1_T2_avg_rating_by_city.png", 1, "Figure: average rating, reliable cities."),
                     ("L1_T2_volume_vs_rating.png", 1, "Figure: restaurant count vs average rating.")],
             insights=[f"{r2['top_city']} alone accounts for {r2['top_city_count'] / 9551 * 100:.0f}% of all records, so any national conclusion is really a Delhi NCR conclusion.",
                       f"Raw ranking is misleading: {r2['best_raw'][0]['City']} tops it with only {int(r2['best_raw'][0]['Rated'])} rated restaurants. Reliable comparison needs a minimum sample size.",
                       f"Among adequately sampled cities, {r2['best_reliable'][0]['City']} ({r2['best_reliable'][0]['Avg_Rating']:.2f}) leads, while the big Delhi NCR cities sit near 3.1-3.3, below the overall mean of {r2['overall_avg']:.2f}."]),
        dict(key="L1T3", folder="Level_1_Basic_Analysis/Task_3_Price_Range_Distribution", title="Task 3 - Price Range Distribution",
             statement="Create a histogram or bar chart of the distribution of price ranges and calculate the percentage of restaurants in each price range.",
             method="The 1-4 Price range scale was tabulated (count, percentage, cumulative percentage). It is used instead of Average Cost for two because costs are in 12 different currencies. India's median cost per range (INR) is shown for context.",
             code="value_counts, percentage table, bar chart with counts and percentages.",
             tables=[lambda: csv_table("Level_1_Basic_Analysis/Task_3_Price_Range_Distribution/price_range_distribution.csv", "Price range distribution (1 = lowest, 4 = highest).", rows=5)],
             charts=[("L1_T3_price_range_distribution.png", 1, "Figure: distribution of price ranges.")],
             insights=[f"{t3[0]['Percentage (%)']:.1f}% of restaurants are in the lowest price range and {t3[0]['Percentage (%)'] + t3[1]['Percentage (%)']:.1f}% in the two lowest, so the data is dominated by affordable dining.",
                       f"Premium (range 4) restaurants are a niche at {t3[3]['Percentage (%)']:.1f}% of the market."]),
        dict(key="L1T4", folder="Level_1_Basic_Analysis/Task_4_Online_Delivery", title="Task 4 - Online Delivery",
             statement="Determine the percentage of restaurants that offer online delivery and compare the average ratings of restaurants with and without it.",
             method="Has Online delivery was converted to a flag. Average ratings (rated restaurants only) were compared overall and within India + UAE, the only markets where delivery is recorded; Mann-Whitney tests check differences.",
             code="boolean flag, groupby comparison, Mann-Whitney U test, bar and box plots.",
             tables=[lambda: csv_table("Level_1_Basic_Analysis/Task_4_Online_Delivery/rating_comparison_all.csv", "Average rating with vs without online delivery - all restaurants."),
                     lambda: csv_table("Level_1_Basic_Analysis/Task_4_Online_Delivery/rating_comparison_india_uae.csv", "Same comparison, India + UAE only."),
                     lambda: csv_table("Level_1_Basic_Analysis/Task_4_Online_Delivery/delivery_by_country.csv", "Delivery availability by country (top rows).", rows=4)],
             charts=[("L1_T4_online_delivery.png", 1, "Figure: delivery share and average ratings."), ("L1_T4_rating_boxplot.png", 1, "Figure: rating distribution, India + UAE.")],
             insights=[f"About {r4['pct_delivery']:.0f}% of restaurants offer online delivery overall; in India it is 28% and in the UAE 47%.",
                       f"Delivery has no meaningful rating effect where it exists (difference {r4['diff_subset']:+.2f} points). The overall gap ({r4['diff_all']:+.2f}) comes from country mix, not from delivery itself.",
                       "Restaurants without delivery are far more often unrated (28.9% vs 3.9%), suggesting delivery-enabled restaurants are more visible on the platform."]),
    ]


def L2_tasks():
    r1, r2, r3, r4 = (R[2][f"task{i}"] for i in range(1, 5))
    return [
        dict(key="L2T1", folder="Level_2_Intermediate_Analysis/Task_1_Restaurant_Ratings", title="Task 1 - Restaurant Ratings",
             statement="Analyze the distribution of aggregate ratings, determine the most common rating range and calculate the average number of votes received by restaurants.",
             method="Rated restaurants were grouped into 0.5-wide rating bands; the platform's rating labels were tabulated including 'Not rated'. Votes were summarised for all and for rated restaurants (mean, median, percentiles).",
             code="pd.cut bands, value_counts, histogram on log-spaced vote bins, descriptive statistics.",
             tables=[lambda: csv_table("Level_2_Intermediate_Analysis/Task_1_Restaurant_Ratings/rating_bands.csv", "Rated restaurants by rating range."),
                     lambda: csv_table("Level_2_Intermediate_Analysis/Task_1_Restaurant_Ratings/votes_summary.csv", "Votes per restaurant - summary statistics.", rows=8)],
             charts=[("L2_T1_rating_distribution.png", 2, "Figure: rating distribution."), ("L2_T1_rating_labels.png", 2, "Figure: restaurants by rating label."), ("L2_T1_votes_distribution.png", 2, "Figure: votes distribution (log scale).")],
             insights=[f"Typical restaurants are rated {r1['top_band']}; scores of 4.5+ are rare ({[b for b in r1['bands'] if b['Rating range'] == '4.5-4.9'][0]['% of rated']:.1f}% of rated), so a rating above 4 is a genuine differentiator.",
                       f"Engagement is very uneven: mean votes {r1['mean_votes_all']:.0f} vs median {r1['median_votes_all']:.0f}; a small set of restaurants collects most votes."]),
        dict(key="L2T2", folder="Level_2_Intermediate_Analysis/Task_2_Cuisine_Combination", title="Task 2 - Cuisine Combination",
             statement="Identify the most common combinations of cuisines and determine whether certain combinations tend to have higher ratings.",
             method="Each restaurant's cuisines were sorted into a canonical combination string. Combinations with at least 20 rated restaurants were compared on average rating (Kruskal-Wallis test). Pairwise co-occurrence and number of cuisines listed were also analysed.",
             code="sorted cuisine lists, groupby combination, itertools.combinations for pairs, scipy Kruskal-Wallis, bar charts.",
             tables=[lambda: csv_table("Level_2_Intermediate_Analysis/Task_2_Cuisine_Combination/cuisine_combinations_all.csv", "Most common cuisine combinations.", cols=["Cuisine_Combo", "Restaurants", "Rated", "Avg_Rating", "Share_%"], rows=10),
                     lambda: csv_table("Level_2_Intermediate_Analysis/Task_2_Cuisine_Combination/combinations_min20_rated.csv", "Highest-rated combinations (at least 20 rated restaurants).", cols=["Cuisine_Combo", "Restaurants", "Rated", "Avg_Rating"], rows=8)],
             charts=[("L2_T2_top_combinations.png", 2, "Figure: most common combinations."), ("L2_T2_combination_ratings.png", 2, "Figure: highest and lowest rated combinations."), ("L2_T2_pairs_and_breadth.png", 2, "Figure: pairs and breadth of cuisine listing.")],
             insights=[f"The most common listing ('{r2['top'][0]['Cuisine_Combo']}') averages {r2['top'][0]['Avg_Rating']:.2f}, below the {R[2]['task1']['mean_rating']:.2f} overall mean; popularity and quality are different things.",
                       f"Ratings differ strongly between combinations ({r2['worst'][-1]['Avg_Rating']:.2f} to {r2['best'][0]['Avg_Rating']:.2f} among {r2['n_qualifying']} comparable combinations); Japanese/Sushi, Italian, American and Mexican lead.",
                       "Opportunity: international cuisines are rated higher but are far less common than North Indian-based combinations."]),
        dict(key="L2T3", folder="Level_2_Intermediate_Analysis/Task_3_Geographic_Analysis", title="Task 3 - Geographic Analysis",
             statement="Plot restaurant locations on a map using longitude and latitude and identify patterns or clusters of restaurants in specific areas.",
             method="Records with valid coordinates were mapped (static plots, an interactive Folium map and a Plotly density map). DBSCAN with haversine distance (700 m radius, minimum 20 restaurants) detected dense hotspots in Delhi NCR.",
             code="matplotlib scatter and hexbin, folium (MarkerCluster, HeatMap, FeatureGroups, LayerControl), scikit-learn DBSCAN, plotly density map.",
             tables=[lambda: csv_table("Level_2_Intermediate_Analysis/Task_3_Geographic_Analysis/dbscan_hotspots.csv", "Largest restaurant hotspots found by DBSCAN.", cols=["Hotspot rank", "Restaurants", "Avg_Rating", "Main_Locality", "Main_City"], rows=8),
                     lambda: csv_table("Level_2_Intermediate_Analysis/Task_3_Geographic_Analysis/top_localities.csv", "Most restaurant-dense localities.", rows=8)],
             charts=[("L2_T3_world_scatter.png", 2, "Figure: all mappable restaurants."), ("L2_T3_ncr_density_hexbin.png", 2, "Figure: Delhi NCR density."), ("L2_T3_top_localities.png", 2, "Figure: top localities.")],
             insights=[f"{r3['ncr_share']:.0f}% of mappable restaurants are in Delhi NCR; {r3['n_hotspots']} DBSCAN hotspots cover {r3['hotspot_cov']:.0f}% of them, so restaurants are concentrated in a few dense areas.",
                       f"Dense, competitive areas (e.g. {r3['top_localities'][0]['Locality']}) differ from areas with fewer restaurants; the interactive map lets analysts explore both.",
                       "Interactive deliverables: Visualizations/Level_2/L2_T3_interactive_map.html (open in a browser; it loads map tiles online) and Task_3 folder maps."]),
        dict(key="L2T4", folder="Level_2_Intermediate_Analysis/Task_4_Restaurant_Chains", title="Task 4 - Restaurant Chains",
             statement="Identify whether restaurant chains are present and analyze the ratings and popularity of different chains.",
             method="Chains were identified as names (case-insensitive) with at least two outlets; major chains have at least 10 outlets. Rating = average over rated outlets; popularity = total and average votes per outlet. Major chains (at least 5 rated outlets) were grouped by median rating and median votes.",
             code="groupby(name).agg(...), quadrant classification, Mann-Whitney chain vs independent, bar charts and bubble chart.",
             tables=[lambda: csv_table("Level_2_Intermediate_Analysis/Task_4_Restaurant_Chains/all_chains.csv", "Chains with the most outlets.", rows=10),
                     lambda: csv_table("Level_2_Intermediate_Analysis/Task_4_Restaurant_Chains/chains_vs_independents.csv", "Chains vs independent restaurants.")],
             charts=[("L2_T4_top_chains_outlets.png", 2, "Figure: chains by outlets."), ("L2_T4_chain_ratings.png", 2, "Figure: average rating of major chains."), ("L2_T4_rating_vs_popularity.png", 2, "Figure: rating vs popularity.")],
             insights=[f"{r4['n_chains']} chains cover {r4['chain_outlets'] / 9551 * 100:.0f}% of restaurants. Size does not equal quality: the largest chains ({r4['top'][0]['Name']}, {r4['top'][1]['Name']}) rate near or below 3.0.",
                       f"{r4['best']['Name']} stands out on both rating ({r4['best']['Avg_Rating']:.2f}) and popularity ({r4['best']['Avg_Votes']:.0f} votes per outlet); chains overall rate lower than independents on average.",
                       "Chain managers can use the quadrant table (Task_4 folder) to find chains that are popular but under-rated, where service consistency is the likely lever."]),
    ]


def L3_tasks():
    r1, r2, r3 = (R[3][f"task{i}"] for i in range(1, 4))
    c = r2["corr"][0]
    sm = {(s["Price range"]): s for s in r3["summary"]}
    return [
        dict(key="L3T1", folder="Level_3_Advanced_Analysis/Task_1_Restaurant_Reviews", title="Task 1 - Restaurant Reviews (BLOCKED - Missing Data)",
             statement="Analyze text reviews to identify the most common positive and negative keywords; calculate the average review length and explore its relationship with rating.",
             method="Before any text analysis, every text column of the dataset was audited (distinct ratio, average words, maximum words) to test whether review text exists. None does; therefore no keywords, lengths or correlations were computed.",
             code="pandas column audit; review_analysis_template.py (ready for future use, not run on real data).",
             tables=[lambda: csv_table("Level_3_Advanced_Analysis/Task_1_Restaurant_Reviews/text_column_audit.csv", "Text-column audit. No column holds review text.", cols=["Column", "Distinct values", "Avg words", "Max words", "Looks like review text?"], rows=13)],
             charts=[],
             insights=["The task cannot be answered with the provided file; fabricating reviews would invalidate the analysis.", "Next action: obtain a review dataset with text per restaurant (from Cognifyz or the data's original source), join on Restaurant ID and run review_analysis_template.py."]),
        dict(key="L3T2", folder="Level_3_Advanced_Analysis/Task_2_Votes_Analysis", title="Task 2 - Votes Analysis",
             statement="Identify the restaurants with the highest and lowest number of votes and analyze whether votes correlate with rating.",
             method="Highest and lowest vote counts were found (ties reported). Pearson, Spearman and log-vote Pearson correlations were computed on rated restaurants; unrated restaurants (rating 0, zero votes) were excluded from the main correlation because 0 is not a real rating.",
             code="sort_values, scipy pearsonr / spearmanr, binned trend, scatter (log x), box plot by rating band.",
             tables=[lambda: csv_table("Level_3_Advanced_Analysis/Task_2_Votes_Analysis/top10_most_voted.csv", "Ten most-voted restaurants.", cols=["Restaurant Name", "City", "Votes", "Aggregate rating"]),
                     lambda: csv_table("Level_3_Advanced_Analysis/Task_2_Votes_Analysis/correlation_results.csv", "Correlation results.", cols=["Sample", "n", "Pearson r", "Spearman rho"]),
                     lambda: csv_table("Level_3_Advanced_Analysis/Task_2_Votes_Analysis/votes_by_rating_band.csv", "Votes by rating band.")],
             charts=[("L3_T2_top_voted_restaurants.png", 3, "Figure: most-voted restaurants."), ("L3_T2_votes_vs_rating_scatter.png", 3, "Figure: votes vs rating."), ("L3_T2_votes_by_rating_band.png", 3, "Figure: votes by rating band.")],
             insights=[f"Highly rated restaurants attract many more votes (Spearman rho = {c['Spearman rho']:.2f}); the top-voted restaurants all rate 4.1 or above, led by Toit in Bangalore.",
                       "Votes work as a popularity signal that reinforces visibility, so improving ratings and encouraging reviews are mutually reinforcing for a restaurant.",
                       f"Roughly {r2['n_zero']:,} restaurants have no votes at all and are unrated, a visibility gap rather than a quality verdict."]),
        dict(key="L3T3", folder="Level_3_Advanced_Analysis/Task_3_Price_Delivery_Table_Booking", title="Task 3 - Price Range vs Online Delivery and Table Booking",
             statement="Analyze whether there is a relationship between price range and the availability of online delivery and table booking, and whether higher-priced restaurants are more likely to offer these services.",
             method="Share of restaurants with each service per price range, chi-square test of independence with Cramer's V, and Spearman rank correlation; repeated for India only because online delivery is recorded only in India and the UAE.",
             code="pd.crosstab, scipy chi2_contingency and spearmanr, grouped bar chart and table heat-map.",
             tables=[lambda: csv_table("Level_3_Advanced_Analysis/Task_3_Price_Delivery_Table_Booking/percentage_summary.csv", "Percentage of restaurants offering each service by price range."),
                     lambda: csv_table("Level_3_Advanced_Analysis/Task_3_Price_Delivery_Table_Booking/statistical_tests.csv", "Statistical tests (p values below 1e-300 are shown as 0).", rows=4)],
             charts=[("L3_T3_service_by_price_range.png", 3, "Figure: service availability by price range."), ("L3_T3_service_heatmap_table.png", 3, "Figure: table view of the percentages.")],
             insights=[f"Table booking rises sharply with price: {sm[1]['India only - Table booking']:.1f}% in range 1 to {sm[4]['India only - Table booking']:.1f}% in range 4 (India). Premium restaurants compete on dine-in experience.",
                       f"Online delivery peaks at mid prices ({sm[2]['India only - Online delivery']:.1f}% in range 2, India) and drops to {sm[4]['India only - Online delivery']:.1f}% in range 4; higher price does not mean more delivery.",
                       "Mid-priced restaurants therefore combine delivery with moderate table booking, while high-end venues focus on booking; this segmentation can guide service-feature recommendations."]),
    ]


LIMITS = {
    1: ["Ratings of 0 mean 'Not rated' and were excluded from averages (22.5% of restaurants).",
        "Outside Delhi NCR most cities have only about 20 records, so city counts reflect how the dataset was assembled and not real city sizes.",
        "Online delivery is only recorded for India and the UAE, so overall comparisons mix markets.",
        "54 city names were damaged by an encoding fault in the source file and repaired by hand-mapping; other text columns still contain unrecoverable characters (see cleaning log).",
        "Average Cost for two is in 12 currencies and was not used for cross-country comparison; Price range was used instead."],
    2: ["Chain detection relies on identical names (no brand ID); unrelated restaurants sharing a name and spelling variants cannot be separated.",
        "Cuisine combinations and ratings depend heavily on location; differences may reflect place rather than cuisine.",
        "497 records have (0, 0) coordinates and 2 Indian records fall outside India; all were excluded from maps. Outside India each city has about 20 points, so no real density patterns exist there.",
        "DBSCAN parameters (700 m, 20 restaurants) are a reasonable but subjective choice; neighbouring dense areas can merge into one large cluster.",
        "The interactive Folium map loads map tiles from the internet."],
    3: ["The dataset has NO review text, so Level 3 Task 1 could not be performed (Blocked - Missing Data).",
        "Correlations describe association, not causation; vote counts also depend on how long a restaurant has been listed, which is not in the data.",
        "Online delivery exists only in India and the UAE; the price-range analysis is therefore also reported for India alone.",
        "Price range is an ordinal 1-4 scale defined by the data source; its exact definition is not documented in the dataset."],
}
OBJ = ["Demonstrate data cleaning, exploratory analysis and statistical testing on a real restaurant dataset.",
       "Answer each official Cognifyz task with reproducible Python code and professional visualizations.",
       "Translate findings into business insights and document limitations honestly."]
TOOLS = "Python 3, pandas, NumPy, SciPy, Matplotlib, Seaborn (installed; Matplotlib used for the final style), Plotly, Folium, scikit-learn (DBSCAN only), Jupyter Notebook, ReportLab (reports) and python-pptx (presentation)."


def dataset_section():
    n = 9551
    return [P(f"The supplied file <b>Dataset.csv</b> contains <b>{n:,} restaurants</b> and 21 columns: identifiers and names, country/city/locality/address, longitude and latitude, "
              "cuisines, average cost for two with currency, table-booking and online-delivery flags, price range (1-4), aggregate rating with colour and text label, and number of votes. "
              "The restaurants cover 15 countries and 141 cities; 90.6% of records are from India and 57.3% from New Delhi."),
            P("<b>Important:</b> the dataset contains <b>no review text</b> and no brand/chain identifier.")]


def cleaning_section():
    c = CLEAN
    items = [f"Rows: {c['rows_raw']:,}; duplicate rows: {c['duplicate_rows']}; duplicate restaurant IDs: {c['duplicate_restaurant_ids']}.",
             f"Missing values: only Cuisines ({c['missing_before'].get('Cuisines', 0)} restaurants); they were kept and excluded from cuisine analysis only.",
             f"Rating 0 equals the 'Not rated' label ({c['unrated_restaurants']:,} restaurants); it was treated as missing for rating statistics. Zero votes were kept for vote analysis.",
             f"{c['placeholder_zero_coordinates']} records have placeholder (0, 0) coordinates; they were excluded from maps only.",
             f"{c['city_names_repaired_rows']} city names (Brasilia, Sao Paulo, Istanbul) were repaired after an encoding fault in the source; other columns keep unrecoverable characters (documented in cleaning_log.json).",
             "Header BOM removed and whitespace stripped; Yes/No columns converted to booleans; country names added from the country code (mapping verified against cities and currencies).",
             "The original file was not modified: Dataset/original_dataset.csv is the untouched copy, and Dataset/cleaned_dataset.csv is the cleaned version."]
    return bullets(items)


def build(path, title, subtitle, levels, task_lists, extra_front=None):
    doc = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=2 * cm, title=title, author=AUTHOR)
    s = []
    # 1 cover
    s += [Spacer(1, 5 * cm), P("Cognifyz Technologies", "sub"), P(esc(title), "title"), P(esc(subtitle), "sub"), Spacer(1, 1.2 * cm),
          P(f"Data Analysis Internship Project", "sub"), P(f"Prepared by: {AUTHOR}", "sub"), P(DATE, "sub"), PageBreak()]
    all_tasks = [t for tl in task_lists for t in tl]
    s += [P("1. Project introduction", "h1"),
          P("This report documents the Cognifyz Technologies Data Analysis Internship tasks " + ", ".join(f"Level {l}" for l in levels) +
            " carried out on a restaurant dataset. Every figure and number in this report was produced by the accompanying Python code from the supplied dataset."),
          P("2. Internship objectives", "h1")] + bullets(OBJ)
    s += [P("3. Tools and technologies used", "h1"), P(esc(TOOLS))]
    s += [P("4. Dataset description", "h1")] + dataset_section()
    s += [P("5. Data cleaning and preprocessing", "h1")] + cleaning_section()
    s += [P("6. Individual task descriptions", "h1")]
    for t in all_tasks:
        s += [P(esc(t["title"]), "h2"), P(esc(t["statement"]))]
    s += [P("7. Methodology", "h1")]
    for t in all_tasks:
        s += [P(esc(t["title"]), "h2"), P(esc(t["method"]))]
    s += [P("8. Python analysis approach", "h1"), P("Each level is a separate script and executed Jupyter notebook that import a shared cleaning and styling module (common.py), so results and chart styling are consistent. Libraries and functions used per task:")]
    for t in all_tasks:
        s += [P(f"<b>{esc(t['title'])}:</b> {esc(t['code'])}")]
    s += [PageBreak(), P("9. Results and visualizations", "h1")]
    for t in all_tasks:
        s += [P(esc(t["title"]), "h2")]
        for tb in t["tables"]: s += tb()
        for name, lvl, cap in t["charts"]: s += [figure(name, lvl, cap)]
        if not t["charts"]: s += [P("No chart is produced: there is no review data to visualize.")]
    s += [P("10. Key observations", "h1")]
    for t in all_tasks:
        s += [P(esc(t["title"]), "h2")] + bullets(findings(0, t["folder"]))
    s += [P("11. Business insights", "h1")]
    for t in all_tasks:
        s += [P(esc(t["title"]), "h2")] + bullets(t["insights"])
    s += [P("12. Limitations", "h1")]
    for l in levels:
        s += ([P(f"Level {l}", "h2")] if len(levels) > 1 else []) + bullets(LIMITS[l])
    s += [P("13. Conclusion", "h1")]
    return doc, s


def finish(doc, s, conclusion):
    s += [P(esc(conclusion))]
    doc.build(s, onFirstPage=lambda c, d: None, onLaterPages=footer)


def matrix_table():
    m = json.loads((RES / "completion_matrix.json").read_text(encoding="utf-8")) if (RES / "completion_matrix.json").exists() else None
    if not m: return []
    df = pd.DataFrame(m)[["Level", "Task", "Status", "Evidence"]]
    return table(df, "Task completion matrix (statuses set by the verification script qa_check.py).", widths=[1.6 * cm, 5 * cm, 3.6 * cm, 6.8 * cm])


CONC = {
    1: "Level 1 answers all four basic tasks from the data: North Indian, Chinese and Fast Food are the top cuisines; New Delhi has the most restaurants while smaller well-sampled cities have higher average ratings; 79% of restaurants are in the two lowest price ranges; and 25.7% offer online delivery with no practical rating advantage where delivery exists.",
    2: "Level 2 shows that ratings concentrate between 3.0 and 3.9, that cuisine combinations and chains differ significantly in rating, that restaurants cluster in a few dense Delhi NCR areas, and that large chains are not automatically well-rated.",
    3: "Level 3 shows a strong positive link between votes and ratings and clear price-based service patterns (table booking rises with price, delivery peaks at mid prices). The review-text task is blocked because the supplied dataset has no review text; this is documented rather than worked around.",
}

if __name__ == "__main__":
    for lvl, fn, tasks in ((1, L1_tasks, None), (2, L2_tasks, None), (3, L3_tasks, None)):
        title = f"Level {lvl} Report"
        names = {1: "Basic Data Analysis", 2: "Intermediate Data Analysis", 3: "Advanced Data Analysis"}
        doc, s = build(OUT / f"Level_{lvl}_Report.pdf", title, names[lvl], [lvl], [fn()])
        finish(doc, s, CONC[lvl]); print("built", f"Level_{lvl}_Report.pdf")

    doc, s = build(OUT / "Final_Internship_Report.pdf", "Final Internship Report", "Data Analysis Internship - Levels 1, 2 and 3", [1, 2, 3], [L1_tasks(), L2_tasks(), L3_tasks()])
    # executive summary + matrix go in front of the conclusion
    s += [P("Task completion matrix", "h2")] + matrix_table()
    finish(doc, s, " ".join(CONC[l] for l in (1, 2, 3)) + " Ten of the eleven official tasks are completed with verified results; one is blocked by missing data.")
    print("built Final_Internship_Report.pdf")
