#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python Level_1_Basic_Analysis/Level_1_Analysis.py
python Level_2_Intermediate_Analysis/Level_2_Analysis.py
python Level_3_Advanced_Analysis/Level_3_Analysis.py
python Reports/build_reports.py   # needs completion_matrix.json from qa_check for the matrix table
python qa_check.py
python Presentation/build_presentation.py
python Reports/build_reports.py
python qa_check.py
