# Cognifyz Technologies - Data Analysis Internship

Complete project covering **all three levels (11 tasks)** on the supplied restaurant dataset (9,551 restaurants, 21 columns, 15 countries).

**Final status: 10 tasks Completed, 1 task Blocked - Missing Data** (Level 3 Task 1 needs review text, which the dataset does not contain).

| Level | Task | Status |
|---|---|---|
| 1 | Top Cuisines | Completed |
| 1 | City Analysis | Completed |
| 1 | Price Range Distribution | Completed |
| 1 | Online Delivery | Completed |
| 2 | Restaurant Ratings | Completed |
| 2 | Cuisine Combination | Completed |
| 2 | Geographic Analysis | Completed |
| 2 | Restaurant Chains | Completed |
| 3 | Restaurant Reviews | **Blocked - Missing Data** (audit + ready template provided) |
| 3 | Votes Analysis | Completed |
| 3 | Price Range vs Online Delivery / Table Booking | Completed |

"Completed" means the key numbers were recomputed independently by `qa_check.py` and the outputs exist.

## How to run

```bash
pip install -r requirements.txt
python Level_1_Basic_Analysis/Level_1_Analysis.py
python Level_2_Intermediate_Analysis/Level_2_Analysis.py
python Level_3_Advanced_Analysis/Level_3_Analysis.py
python qa_check.py                      # independent verification + completion matrix
python Reports/build_reports.py         # four PDF reports
python Presentation/build_presentation.py
```

The notebooks (`Level_N_Analysis.ipynb`) contain the same code with Markdown explanations and inline charts; open them in Jupyter or Google Colab (upload the whole folder so `common.py` and `Dataset/` are found). Run scripts from any directory; paths are resolved relative to the files.
Python 3.10+ recommended. The interactive map loads map tiles online.

## Folder structure

```
Dataset/                 original_dataset.csv (untouched) + cleaned_dataset.csv
common.py                shared cleaning rules, chart style, export helpers
Level_1_Basic_Analysis/  script, notebook, Task_1..4 folders (tables + findings.md)
Level_2_Intermediate_Analysis/   same, plus interactive Folium/Plotly maps in Task_3
Level_3_Advanced_Analysis/       same, plus review_analysis_template.py in Task_1
Visualizations/Level_1..3/       high-resolution PNG charts (200 dpi) + interactive map HTML
Reports/                 Level_1/2/3 reports + Final_Internship_Report (PDF); results/ holds JSON used by reports
Presentation/            Internship_Presentation.pptx (21 slides)
Submission/              LinkedIn_Post.md, Video_Demonstration_Script.md, Submission_Checklist.md
qa_check.py              verification script
```

## Key data decisions (details in the reports and `Reports/results/cleaning_log.json`)
- Rating 0 = "Not rated" (2,148 restaurants) -> excluded from rating averages.
- Cuisine percentages use the 9,542 restaurants that list a cuisine.
- Online delivery is recorded only in India and the UAE; comparisons are shown overall and for those markets.
- City ranking by rating uses cities with at least 20 rated restaurants (tiny samples are unreliable).
- Chains are detected by identical restaurant name (no brand ID in the data).
- 497 (0, 0) coordinates and 54 damaged city names were handled as documented.

## Limitations
No review text (Level 3 Task 1); no chain identifier; 90.6% of data from India and 57.3% from New Delhi, with most other cities contributing about 20 records.

## Not done on your behalf
No LinkedIn post has been published and no submission form has been submitted. See `Submission/Submission_Checklist.md`.
