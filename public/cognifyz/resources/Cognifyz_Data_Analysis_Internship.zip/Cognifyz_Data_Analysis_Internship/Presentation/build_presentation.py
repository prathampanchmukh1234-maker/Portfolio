"""build_presentation.py - creates Internship_Presentation.pptx from the real analysis results (run after the Level scripts and qa_check.py)."""
import json
from pathlib import Path

from PIL import Image
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "Reports" / "results"
R = {l: json.loads((RES / f"level_{l}_results.json").read_text(encoding="utf-8")) for l in (1, 2, 3)}
CL = json.loads((RES / "cleaning_log.json").read_text(encoding="utf-8"))
MATRIX = json.loads((RES / "completion_matrix.json").read_text(encoding="utf-8"))
NAVY, BLUE, ORANGE = RGBColor(0x14, 0x2F, 0x57), RGBColor(0x2A, 0x78, 0xD6), RGBColor(0xEB, 0x68, 0x34)
INK, GREY, LIGHT, WHITE = RGBColor(0x1b, 0x1b, 0x1b), RGBColor(0x5a, 0x59, 0x56), RGBColor(0xEE, 0xF2, 0xF8), RGBColor(0xFF, 0xFF, 0xFF)
FONT = "Calibri"

prs = Presentation()
prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
BLANK = prs.slide_layouts[6]
page = [0]


def text(slide, x, y, w, h, paras, size=16, color=INK, bold=False, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, bullet=False, space=8):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h)); tf = tb.text_frame; tf.word_wrap = True; tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = Inches(0.05)
    paras = paras if isinstance(paras, list) else [paras]
    for i, t in enumerate(paras):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align; p.space_after = Pt(space)
        r = p.add_run(); r.text = ("•  " + t) if bullet else t
        r.font.size, r.font.bold, r.font.name = Pt(size), bold, FONT; r.font.color.rgb = color
    return tb


def rect(slide, x, y, w, h, fill, line=False):
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    s.fill.solid(); s.fill.fore_color.rgb = fill
    if not line: s.line.fill.background()
    s.shadow.inherit = False
    return s


def base(title, kicker=None):
    s = prs.slides.add_slide(BLANK); page[0] += 1
    rect(s, 0, 0, 13.333, 1.15, NAVY); rect(s, 0, 1.15, 13.333, 0.06, ORANGE)
    text(s, 0.55, 0.14, 12.2, 0.9, title, size=26, color=WHITE, bold=True, anchor=MSO_ANCHOR.MIDDLE)
    if kicker: text(s, 0.55, 7.0, 9, 0.35, kicker, size=10, color=GREY)
    text(s, 10.2, 7.0, 2.6, 0.35, f"Cognifyz Technologies  |  {page[0]}", size=10, color=GREY, align=PP_ALIGN.RIGHT)
    return s


def picture(slide, rel, x, y, w, h):
    p = ROOT / rel; iw, ih = Image.open(p).size
    sc = min(w / iw, h / ih); pw, ph = iw * sc, ih * sc
    slide.shapes.add_picture(str(p), Inches(x + (w - pw) / 2), Inches(y + (h - ph) / 2), Inches(pw), Inches(ph))


def chart_slide(title, img, points, kicker, img2=None, size=15):
    s = base(title, kicker)
    if img2:
        picture(s, img, 0.4, 1.45, 6.1, 4.1); picture(s, img2, 0.4, 5.0, 0.1, 0.1) if False else None
        picture(s, img, 0.4, 1.45, 7.6, 5.4)
    else:
        picture(s, img, 0.4, 1.45, 7.7, 5.4)
    rect(s, 8.3, 1.55, 4.7, 5.25, LIGHT)
    text(s, 8.5, 1.7, 4.3, 0.4, "Key findings", size=14, color=BLUE, bold=True)
    text(s, 8.5, 2.15, 4.3, 4.6, points, size=size, bullet=True, space=10)
    return s


L1, L2, L3 = R[1], R[2], R[3]
t3 = {t["Price range"]: t for t in L1["task3"]["table"]}
bands = {b["Rating range"]: b for b in L2["task1"]["bands"]}
corr = L3["task2"]["corr"]
sm = {s["Price range"]: s for s in L3["task3"]["summary"]}

# 1 Title
s = prs.slides.add_slide(BLANK); page[0] += 1
rect(s, 0, 0, 13.333, 7.5, NAVY); rect(s, 0.8, 3.55, 1.6, 0.07, ORANGE)
text(s, 0.8, 1.5, 11, 0.6, "COGNIFYZ TECHNOLOGIES  |  DATA ANALYSIS INTERNSHIP", size=16, color=RGBColor(0xA9, 0xC6, 0xEC), bold=True)
text(s, 0.8, 2.1, 11.5, 1.4, "Restaurant Data Analysis", size=48, color=WHITE, bold=True)
text(s, 0.8, 3.85, 11, 1.2, ["Levels 1, 2 and 3: eleven tasks on 9,551 restaurants", "Prepared by Pratham  |  November 2026"], size=20, color=WHITE)
text(s, 0.8, 6.6, 11, 0.4, "#cognifyz  #cognifyztech  #cognifyztechnologies", size=13, color=RGBColor(0xA9, 0xC6, 0xEC))

# 2 Overview
s = base("Internship overview", "Source: Cognifyz internship programme document")
text(s, 0.6, 1.6, 6.0, 5, ["Cognifyz Technologies is a data science company offering AI, machine learning and data analytics products, plus training programmes.",
                         "Data Analysis internship: three levels of increasing difficulty (the programme requires any two).",
                         "Scope delivered here: all three levels, every task, with a separate file per level.",
                         "Required proof of work: a LinkedIn video tagging Cognifyz with #cognifyz #cognifyztech #cognifyztechnologies."], size=16, bullet=True, space=12)
for i, (lv, desc, c) in enumerate([("Level 1", "Basic: cuisines, cities, price range, online delivery", BLUE), ("Level 2", "Intermediate: ratings, cuisine combos, geography, chains", RGBColor(0x1B, 0xAF, 0x7A)),
                                    ("Level 3", "Advanced: reviews, votes, price vs services", ORANGE)]):
    rect(s, 7.2, 1.7 + i * 1.7, 5.5, 1.45, LIGHT); rect(s, 7.2, 1.7 + i * 1.7, 0.12, 1.45, c)
    text(s, 7.5, 1.78 + i * 1.7, 5, 0.5, lv, size=20, bold=True, color=NAVY); text(s, 7.5, 2.3 + i * 1.7, 5, 0.8, desc, size=15, color=GREY)

# 3 Objectives
s = base("Project objectives")
for i, (h, d) in enumerate([("Clean and prepare", "Inspect, clean and document every preprocessing decision"), ("Explore and test", "EDA and statistical tests (Mann-Whitney, Kruskal-Wallis, chi-square, correlation)"),
                            ("Visualize", "Consistent, presentation-ready charts and an interactive map"), ("Advise", "Business insights with honest limitations")]):
    x = 0.6 + (i % 2) * 6.2; y = 1.7 + (i // 2) * 2.5
    rect(s, x, y, 5.9, 2.2, LIGHT); text(s, x + 0.25, y + 0.2, 5.4, 0.5, h, size=20, bold=True, color=BLUE); text(s, x + 0.25, y + 0.85, 5.4, 1.3, d, size=16, color=INK)

# 4 Dataset overview
s = base("Dataset overview", "Source: Dataset.csv")
for i, (n, l) in enumerate([("9,551", "restaurants"), ("21", "columns"), ("15", "countries"), ("141", "cities"), ("2,148", "unrated (rating 0)"), ("0", "review-text columns")]):
    x = 0.6 + (i % 3) * 4.1; y = 1.7 + (i // 3) * 1.9
    rect(s, x, y, 3.8, 1.6, LIGHT); text(s, x, y + 0.1, 3.8, 0.9, n, size=38, bold=True, color=BLUE if i != 5 else ORANGE, align=PP_ALIGN.CENTER)
    text(s, x, y + 0.95, 3.8, 0.5, l, size=15, color=GREY, align=PP_ALIGN.CENTER)
text(s, 0.6, 5.6, 12.2, 1.3, ["Columns cover location (city, locality, coordinates), cuisines, price range, services (online delivery, table booking), rating and votes.",
                              "90.6% of records are from India and 57.3% from New Delhi; most other cities contribute about 20 records each."], size=15, bullet=True)

# 5 Tech stack
s = base("Technology stack")
for i, (h, d) in enumerate([("Python 3 + Jupyter", "Scripts and executed notebooks per level"), ("pandas, NumPy, SciPy", "Cleaning, aggregation, statistical tests"), ("Matplotlib", "High-resolution PNG charts, one consistent style"),
                            ("Folium + Plotly", "Interactive maps: clusters, heat map, hotspots"), ("scikit-learn", "DBSCAN hotspot detection only"), ("ReportLab, python-pptx", "PDF reports and this presentation")]):
    x = 0.6 + (i % 3) * 4.1; y = 1.7 + (i // 3) * 2.5
    rect(s, x, y, 3.8, 2.2, LIGHT); text(s, x + 0.2, y + 0.2, 3.4, 0.9, h, size=19, bold=True, color=NAVY); text(s, x + 0.2, y + 1.15, 3.4, 1.0, d, size=14.5, color=GREY)

# 6 Cleaning
s = base("Data cleaning and preprocessing", "Full log: Reports/results/cleaning_log.json")
text(s, 0.6, 1.6, 12.1, 5.2, [f"No duplicate rows or IDs; only 9 missing values (Cuisines) - kept, excluded from cuisine tasks only.",
                            f"Rating 0 = 'Not rated' ({CL['unrated_restaurants']:,} restaurants): treated as missing in every rating average.",
                            f"{CL['placeholder_zero_coordinates']} placeholder (0, 0) coordinates excluded from maps only.",
                            f"{CL['city_names_repaired_rows']} city names damaged by an encoding fault in the source file were repaired (Brasilia, Sao Paulo, Istanbul).",
                            "Cost for two is in 12 currencies: Price range (1-4) used for cross-country analysis.",
                            "Original file left untouched; cleaned copy saved separately."], size=18, bullet=True, space=14)

# Level 1
t = L1["task1"]["top3"]
chart_slide("Level 1 - Top cuisines: North Indian, Chinese, Fast Food", "Visualizations/Level_1/L1_T1_top_cuisines.png",
            [f"{t[0]['Cuisine']}: {t[0]['Restaurants']:,} restaurants ({t[0]['% of restaurants with cuisine info']:.1f}%)", f"{t[1]['Cuisine']}: {t[1]['Restaurants']:,} ({t[1]['% of restaurants with cuisine info']:.1f}%)",
             f"{t[2]['Cuisine']}: {t[2]['Restaurants']:,} ({t[2]['% of restaurants with cuisine info']:.1f}%)", f"{L1['task1']['distinct']} distinct cuisines, heavily concentrated on a few."], "Base: 9,542 restaurants with cuisine info")
r2 = L1["task2"]
chart_slide("Level 1 - New Delhi dominates; small cities rate higher", "Visualizations/Level_1/L1_T2_avg_rating_by_city.png",
            [f"Most restaurants: {r2['top_city']} ({r2['top_city_count']:,}, 57% of data)", f"Highest average rating (>= 20 rated): {r2['best_reliable'][0]['City']} ({r2['best_reliable'][0]['Avg_Rating']:.2f})",
             f"Raw top ({r2['best_raw'][0]['City']}, {r2['best_raw'][0]['Avg_Rating']:.1f}) rests on {int(r2['best_raw'][0]['Rated'])} restaurants - not reliable", "Most non-NCR cities have only about 20 records: a sampling effect."], "Ratings: rated restaurants only")
chart_slide("Level 1 - Almost half of restaurants are in the lowest price range", "Visualizations/Level_1/L1_T3_price_range_distribution.png",
            [f"Range 1: {t3[1]['Percentage (%)']:.1f}%   Range 2: {t3[2]['Percentage (%)']:.1f}%", f"Range 3: {t3[3]['Percentage (%)']:.1f}%   Range 4: {t3[4]['Percentage (%)']:.1f}%",
             f"Ranges 1-2 together: {t3[1]['Percentage (%)'] + t3[2]['Percentage (%)']:.1f}%", "Counts fall at every step up the price scale."], "Price range: 1 = lowest, 4 = highest")
r4 = L1["task4"]
chart_slide("Level 1 - Delivery: 25.7% offer it, with little rating effect", "Visualizations/Level_1/L1_T4_online_delivery.png",
            [f"{r4['pct_delivery']:.1f}% of restaurants offer online delivery", "Only recorded in India (28%) and UAE (47%)", f"Overall rating gap {r4['diff_all']:+.2f}; inside India + UAE only {r4['diff_subset']:+.2f}", "The overall gap is a country-mix effect, not a delivery effect."], "Ratings: rated restaurants only")

# Level 2
r = L2["task1"]
chart_slide(f"Level 2 - Most common rating range: {r['top_band']}", "Visualizations/Level_2/L2_T1_rating_distribution.png",
            [f"{bands[r['top_band']]['% of rated']:.1f}% of rated restaurants score {r['top_band']}", f"Average rating {r['mean_rating']:.2f}; 4.5+ is only {bands['4.5-4.9']['% of rated']:.1f}%",
             f"Average votes: {r['mean_votes_all']:.0f} (median {r['median_votes_all']:.0f})", "A few very popular restaurants lift the mean."], "Unrated (22.5%) excluded from rating bands")
r = L2["task2"]
chart_slide("Level 2 - Cuisine combinations differ clearly in rating", "Visualizations/Level_2/L2_T2_combination_ratings.png",
            [f"{r['n_combos']:,} distinct combinations; most common: '{r['top'][0]['Cuisine_Combo']}'", f"Best rated: {r['best'][0]['Cuisine_Combo']} ({r['best'][0]['Avg_Rating']:.2f})", f"Lowest: {r['worst'][-1]['Cuisine_Combo']} ({r['worst'][-1]['Avg_Rating']:.2f})",
             "Differences are statistically significant (Kruskal-Wallis p < 1e-100)."], "Combinations with >= 20 rated restaurants", size=14.5)
r = L2["task3"]
chart_slide("Level 2 - Restaurants cluster in a few dense Delhi NCR areas", "Visualizations/Level_2/L2_T3_ncr_density_hexbin.png",
            [f"{r['mappable']:,} restaurants mapped; {r['ncr_share']:.0f}% are in Delhi NCR", f"DBSCAN found {r['n_hotspots']} hotspots covering {r['hotspot_cov']:.0f}% of NCR restaurants", f"Densest localities: {r['top_localities'][0]['Locality']}, {r['top_localities'][1]['Locality']}, {r['top_localities'][2]['Locality']}",
             "Interactive Folium map: clusters, heat map, city bubbles, hotspots."], "Interactive map: Visualizations/Level_2/L2_T3_interactive_map.html")
r = L2["task4"]
chart_slide("Level 2 - Chains are common, but size does not mean quality", "Visualizations/Level_2/L2_T4_rating_vs_popularity.png",
            [f"{r['n_chains']} chains cover {r['chain_outlets'] / 95.51:.0f}% of restaurants ({r['n_major']} with 10+ outlets)", f"Largest: {r['top'][0]['Name']} ({r['top'][0]['Outlets']}), {r['top'][1]['Name']} ({r['top'][1]['Outlets']})",
             f"Best: {r['best']['Name']} - rating {r['best']['Avg_Rating']:.2f}, {r['best']['Avg_Votes']:.0f} votes per outlet", "Chains average a lower rating than independents (3.34 vs 3.49)."], "Chains = identical name, 2+ outlets")

# Level 3
s = base("Level 3 - Restaurant reviews: blocked by missing data", "Audit: Level_3_Advanced_Analysis/Task_1_Restaurant_Reviews")
rect(s, 0.6, 1.6, 12.1, 1.2, RGBColor(0xFD, 0xEE, 0xE7)); text(s, 0.85, 1.7, 11.6, 1.0, "The supplied dataset contains no review text, so keywords, review length and its relation to rating cannot be computed. Nothing was invented.", size=18, bold=True, color=ORANGE, anchor=MSO_ANCHOR.MIDDLE)
text(s, 0.6, 3.1, 12.1, 3.8, ["Audit of all 13 text columns: none looks like review text (longest column averages 8.7 words - addresses).",
                              "'Rating text' has only 6 fixed labels (Excellent ... Poor, Not rated): a category derived from the rating, not a review.",
                              "Next action: obtain a review dataset with text per restaurant (Cognifyz or the data's source), join on Restaurant ID, run review_analysis_template.py.",
                              "Status in the completion matrix: Blocked - Missing Data."], size=17, bullet=True, space=12)
r = L3["task2"]
chart_slide("Level 3 - Better-rated restaurants get far more votes", "Visualizations/Level_3/L3_T2_votes_vs_rating_scatter.png",
            [f"Most votes: {r['highest'][0]['Restaurant Name']} ({r['highest'][0]['City']}), {r['highest'][0]['Votes']:,}", f"Fewest: {r['n_zero']:,} restaurants tie at 0 votes (all unrated)", f"Pearson r = {corr[0]['Pearson r']:.2f}, Spearman rho = {corr[0]['Spearman rho']:.2f} (rated only)",
             "Holds within Delhi NCR (rho = 0.59). Association, not causation."], "Rated restaurants, n = 7,403")
chart_slide("Level 3 - Table booking rises with price; delivery peaks mid-price", "Visualizations/Level_3/L3_T3_service_by_price_range.png",
            [f"Table booking (India): {sm[1]['India only - Table booking']:.1f}% -> {sm[2]['India only - Table booking']:.1f}% -> {sm[3]['India only - Table booking']:.1f}% -> {sm[4]['India only - Table booking']:.1f}%", f"Delivery (India): {sm[1]['India only - Online delivery']:.1f}% -> {sm[2]['India only - Online delivery']:.1f}% -> {sm[3]['India only - Online delivery']:.1f}% -> {sm[4]['India only - Online delivery']:.1f}%",
             "Higher-priced restaurants are more likely to take bookings, but not more likely to deliver.", "Chi-square tests significant for both (Cramer's V 0.63 booking, 0.30 delivery, India)."], "Price range: 1 = lowest, 4 = highest")

# Insights
s = base("Major business insights")
ins = [("Premium dining is booking-led", "Table booking climbs to about 65% in the top price tier while delivery falls to 11%."), ("Mid-price is the delivery sweet spot", "45% of range-2 restaurants in India offer delivery."),
       ("International cuisines score higher", "Japanese/Sushi, Italian, American and Mexican lead ratings but are rare."), ("Size is not quality", "The biggest chains rate near 3.0; Barbeque Nation leads with 4.35."),
       ("Visibility compounds", "More votes go to better-rated restaurants; 1,094 restaurants have no votes at all.")]
for i, (h, d) in enumerate(ins):
    y = 1.5 + i * 1.07
    rect(s, 0.6, y, 12.1, 0.95, LIGHT); rect(s, 0.6, y, 0.1, 0.95, BLUE)
    text(s, 0.9, y + 0.05, 4.2, 0.85, h, size=17, bold=True, color=NAVY, anchor=MSO_ANCHOR.MIDDLE); text(s, 5.2, y + 0.05, 7.4, 0.85, d, size=15, color=INK, anchor=MSO_ANCHOR.MIDDLE)

# Challenges
s = base("Challenges and solutions")
rows = [("Rating 0 means 'not rated'", "Treated as missing in rating averages; kept for vote analysis"), ("Delivery exists only in India and UAE", "Reported overall and for India + UAE / India only"),
        ("Tiny city samples distort rankings", "Reliability threshold of 20 rated restaurants"), ("No review text in the data", "Audited, documented as blocked, template prepared"),
        ("No chain identifier", "Chains detected by identical name; limitation documented"), ("Encoding damage in source file", "Repaired city names; flagged other columns")]
for i, (c, sol) in enumerate(rows):
    y = 1.5 + i * 0.9
    rect(s, 0.6, y, 5.6, 0.78, LIGHT); rect(s, 6.4, y, 6.3, 0.78, LIGHT)
    text(s, 0.75, y, 5.3, 0.78, c, size=15, bold=True, color=ORANGE, anchor=MSO_ANCHOR.MIDDLE); text(s, 6.55, y, 6.0, 0.78, sol, size=14.5, anchor=MSO_ANCHOR.MIDDLE)
text(s, 0.6, 1.1 + 0.0, 0.1, 0.1, "", size=1)

# Matrix
s = base("Task completion matrix", "Statuses set by qa_check.py after independent recomputation of key numbers")
tbl = s.shapes.add_table(len(MATRIX) + 1, 3, Inches(0.6), Inches(1.5), Inches(12.1), Inches(5.2)).table
for j, (h, w) in enumerate([("Task", 5.2), ("Status", 2.9), ("Evidence", 4.0)]):
    tbl.columns[j].width = Inches(w); c = tbl.cell(0, j); c.text = h; c.fill.solid(); c.fill.fore_color.rgb = NAVY
    c.text_frame.paragraphs[0].runs[0].font.color.rgb = WHITE; c.text_frame.paragraphs[0].runs[0].font.size = Pt(13); c.text_frame.paragraphs[0].runs[0].font.bold = True
for i, m in enumerate(MATRIX, start=1):
    for j, v in enumerate([f"{m['Level']} - {m['Task']}", m["Status"], m["Evidence"]]):
        c = tbl.cell(i, j); c.text = v; c.fill.solid(); c.fill.fore_color.rgb = LIGHT if i % 2 else WHITE
        run = c.text_frame.paragraphs[0].runs[0]; run.font.size = Pt(12); run.font.name = FONT
        run.font.color.rgb = ORANGE if (j == 1 and m["Status"] != "Completed") else INK; run.font.bold = (j == 1)

# Conclusion
s = base("Conclusion")
text(s, 0.6, 1.6, 12.1, 4.2, ["Ten of eleven official tasks are completed from the real dataset; one (Level 3 reviews) is blocked because the data has no review text.",
                            "Delhi NCR dominates the data, so findings are most reliable for North India; many other cities are small samples.",
                            "Strongest results: ratings and votes move together; table booking rises with price while delivery peaks mid-price; cuisine mix and chain size are weak predictors of quality.",
                            "Everything is reproducible: scripts, executed notebooks, tables, charts, an interactive map and four PDF reports."], size=18, bullet=True, space=14)
rect(s, 0.6, 5.9, 12.1, 0.9, NAVY); text(s, 0.8, 5.9, 11.7, 0.9, "Thank you  |  #cognifyz  #cognifyztech  #cognifyztechnologies", size=18, color=WHITE, bold=True, anchor=MSO_ANCHOR.MIDDLE)

out = Path(__file__).resolve().parent / "Internship_Presentation.pptx"
prs.save(out); print("saved", out, "slides:", len(prs.slides))
