# Level 2 - Task 4: Restaurant Chains

- Yes - chains exist: 742 restaurant names appear at least twice, covering 2,860 restaurants (29.9% of the dataset); 40 have 10 or more outlets.
- Largest chains by outlets: Cafe Coffee Day (83), Domino's Pizza (79), Subway (63), Green Chick Chop (51) and McDonald's (48).
- Among major chains (>= 10 outlets, >= 5 rated), the highest average rating is Barbeque Nation (4.35, 26 outlets) and the lowest is Wah Ji Wah (2.62, 19 outlets).
- Most popular by average votes per outlet: Barbeque Nation (1082); most total votes across all outlets: Barbeque Nation (28,142).
- Chain outlets average 3.34 vs 3.49 for restaurants with a unique name (Mann-Whitney p = 1.2e-23); average votes 180 vs 147.
- Performance groups (medians as cut-offs): Higher rating, more votes: 11; Lower rating, fewer votes: 10; Lower rating, more votes: 9; Higher rating, fewer votes: 9.
- Caveat: chains are detected by identical names; unrelated restaurants sharing a name, and spelling variants, cannot be separated with the available columns.
