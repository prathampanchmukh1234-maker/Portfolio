# Level 2 - Task 1: Restaurant Ratings

- Most common rating range (rated restaurants): 3.0-3.4, with 2,490 restaurants (33.6% of rated). The single most frequent rating value is 3.2.
- Rated restaurants average 3.44 (median 3.4, std 0.55); skewness is 0.23, so the distribution is right-skewed.
- Rating labels: Average 39.1%, Good 22.0%, Very Good 11.3%, Excellent 3.1%, Poor 1.9%; 22.5% are not rated.
- Average votes per restaurant: 156.9 across all 9,551 restaurants (median 31); 202.2 across rated restaurants only (median 60).
- 1,094 restaurants have zero votes; the top 10% of restaurants have at least 379 votes, so a small group of very popular restaurants lifts the mean.
