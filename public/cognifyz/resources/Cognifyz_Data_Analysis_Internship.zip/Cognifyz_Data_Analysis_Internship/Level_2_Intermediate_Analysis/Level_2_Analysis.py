# %% [markdown]
# # Cognifyz Technologies - Data Analysis Internship
# ## Level 2: Intermediate Data Analysis
# Tasks: (1) Restaurant Ratings, (2) Cuisine Combination, (3) Geographic Analysis, (4) Restaurant Chains.
#
# Conventions carried over from Level 1: rating `0` means *Not rated* and is excluded from rating averages;
# restaurants without a cuisine are excluded from cuisine questions; (0, 0) coordinates are placeholders.

# %%
import sys
from pathlib import Path
try:
    HERE = Path(__file__).resolve().parent
except NameError:
    HERE = Path.cwd()
sys.path.insert(0, str(HERE.parent))

from itertools import combinations
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
import common as cz
from common import BLUE, ORANGE, AQUA, INK, INK2, MUTED, FADED, GRID

try:
    from IPython.display import display
except ImportError:
    display = print
pd.set_option("display.width", 150)
L2 = HERE
RES = {}
df, clog = cz.load_clean(save=False)
rated = df[df["Is_Rated"]]
print(f"{len(df):,} restaurants | {len(rated):,} rated")

# %% [markdown]
# ---
# ## Task 1 - Restaurant Ratings
# * Distribution of `Aggregate rating` for rated restaurants (0.5-wide bands), plus the platform's own `Rating text` labels.
# * Average number of votes per restaurant (reported for all restaurants and for rated restaurants only).

# %%
T1 = L2 / "Task_1_Restaurant_Ratings"
edges = np.arange(1.5, 5.01, 0.5)
labels = [f"{a:.1f}-{b - 0.1:.1f}" if b < 5.0 else "4.5-4.9" for a, b in zip(edges[:-1], edges[1:])]
band = pd.cut(rated["Rating"], bins=list(edges[:-1]) + [5.01], labels=labels, right=False)
band_tbl = band.value_counts().reindex(labels).to_frame("Restaurants")
band_tbl["% of rated"] = (band_tbl["Restaurants"] / len(rated) * 100).round(2)
band_tbl.index.name = "Rating range"
cz.save_table(band_tbl, T1, "rating_bands")
display(band_tbl)

text_tbl = df["Rating text"].value_counts().reindex(["Excellent", "Very Good", "Good", "Average", "Poor", "Not rated"]).to_frame("Restaurants")
text_tbl["% of all"] = (text_tbl["Restaurants"] / len(df) * 100).round(2)
cz.save_table(text_tbl, T1, "rating_text_counts")
display(text_tbl)

top_band = band_tbl["Restaurants"].idxmax()
mode_val = rated["Rating"].mode().iloc[0]
vote_stats = pd.DataFrame({
    "All restaurants": df["Votes"].describe(percentiles=[.5, .9]),
    "Rated restaurants only": rated["Votes"].describe(percentiles=[.5, .9])}).round(2)
cz.save_table(vote_stats, T1, "votes_summary")
display(vote_stats)
skew = rated["Rating"].skew()

# %%
fig, ax = cz.new_fig(10, 6)
ax.bar(band_tbl.index, band_tbl["Restaurants"], color=[BLUE if i == top_band else FADED for i in band_tbl.index], width=0.65)
cz.label_bars(ax, values=[f"{r:,}\n({p:.1f}%)" for r, p in zip(band_tbl["Restaurants"], band_tbl["% of rated"])], fmt="{}")
ax.set_ylim(0, band_tbl["Restaurants"].max() * 1.2); cz.thousands(ax)
ax.set_xlabel("Aggregate rating range"); ax.set_ylabel("Number of restaurants"); ax.grid(axis="x", visible=False)
cz.titled(fig, f"The most common rating range is {top_band}",
          f"Distribution of aggregate ratings, {len(rated):,} rated restaurants ({(~df['Is_Rated']).sum():,} unrated excluded)")
cz.save_fig(fig, 2, "L2_T1_rating_distribution"); fig

# %%
fig, ax = cz.new_fig(10, 5.5)
cat = text_tbl.iloc[::-1]
ax.barh(cat.index, cat["Restaurants"], color=[FADED if i == "Not rated" else BLUE for i in cat.index], height=0.62)
cz.label_bars(ax, values=[f"{r:,} ({p:.1f}%)" for r, p in zip(cat["Restaurants"], cat["% of all"])], fmt="{}", horizontal=True)
ax.set_xlim(0, cat["Restaurants"].max() * 1.25); cz.thousands(ax, "x"); ax.grid(axis="y", visible=False)
ax.set_xlabel("Number of restaurants")
cz.titled(fig, "'Average' is the largest rating label; over one in five restaurants is unrated",
          "Restaurants by rating label (Excellent 4.5+, Very Good 4.0-4.4, Good 3.5-3.9, Average 2.5-3.4, Poor below 2.5)")
cz.save_fig(fig, 2, "L2_T1_rating_labels"); fig

# %%
fig, ax = cz.new_fig(10, 6)
ax.hist(df["Votes"].clip(lower=1), bins=np.logspace(0, np.log10(df["Votes"].max()), 40), color=BLUE, edgecolor=cz.SURFACE)
ax.set_xscale("log")
m, md = df["Votes"].mean(), df["Votes"].median()
ax.axvline(m, color=ORANGE, lw=1.8, ls="--"); ax.axvline(max(md, 1), color=INK2, lw=1.8, ls=":")
ymax = ax.get_ylim()[1]
ax.annotate(f"Mean {m:,.0f}", (m, ymax * 0.93), xytext=(6, 0), textcoords="offset points", color=INK2, fontsize=10)
ax.annotate(f"Median {md:,.0f}", (max(md, 1), ymax * 0.84), xytext=(-6, 0), textcoords="offset points", color=INK2, fontsize=10, ha="right")
ax.set_xlabel("Votes per restaurant (log scale; zero-vote restaurants shown at 1)"); ax.set_ylabel("Number of restaurants"); cz.thousands(ax)
cz.titled(fig, f"Votes are heavily skewed: the mean ({m:,.0f}) is far above the median ({md:,.0f})",
          f"Distribution of votes across {len(df):,} restaurants")
cz.save_fig(fig, 2, "L2_T1_votes_distribution"); fig

# %%
obs_r = [
    f"Most common rating range (rated restaurants): {top_band}, with {band_tbl.loc[top_band,'Restaurants']:,} restaurants ({band_tbl.loc[top_band,'% of rated']:.1f}% of rated). "
    f"The single most frequent rating value is {mode_val:.1f}.",
    f"Rated restaurants average {rated['Rating'].mean():.2f} (median {rated['Rating'].median():.1f}, std {rated['Rating'].std():.2f}); skewness is {skew:.2f}, so the distribution is "
    f"{'slightly left-skewed (a longer tail of low scores)' if skew < -0.1 else 'roughly symmetric' if abs(skew) <= 0.1 else 'right-skewed'}.",
    f"Rating labels: Average {text_tbl.loc['Average','% of all']:.1f}%, Good {text_tbl.loc['Good','% of all']:.1f}%, Very Good {text_tbl.loc['Very Good','% of all']:.1f}%, "
    f"Excellent {text_tbl.loc['Excellent','% of all']:.1f}%, Poor {text_tbl.loc['Poor','% of all']:.1f}%; {text_tbl.loc['Not rated','% of all']:.1f}% are not rated.",
    f"Average votes per restaurant: {df['Votes'].mean():.1f} across all {len(df):,} restaurants (median {df['Votes'].median():.0f}); "
    f"{rated['Votes'].mean():.1f} across rated restaurants only (median {rated['Votes'].median():.0f}).",
    f"{int((df['Votes'] == 0).sum()):,} restaurants have zero votes; the top 10% of restaurants have at least {df['Votes'].quantile(.9):.0f} votes, "
    f"so a small group of very popular restaurants lifts the mean.",
]
for o in obs_r: print("-", o)
cz.save_findings(T1, "Level 2 - Task 1: Restaurant Ratings", obs_r)
RES["task1"] = {"top_band": top_band, "bands": band_tbl.reset_index().to_dict("records"), "mode": mode_val, "mean_rating": rated["Rating"].mean(),
                "mean_votes_all": df["Votes"].mean(), "median_votes_all": df["Votes"].median(), "mean_votes_rated": rated["Votes"].mean(),
                "text_counts": text_tbl.reset_index().to_dict("records"), "observations": obs_r}

# %% [markdown]
# ---
# ## Task 2 - Cuisine Combination
# A *combination* is the full set of cuisines a restaurant lists (alphabetically ordered, so "Chinese, North Indian" and
# "North Indian, Chinese" are the same). Ratings use rated restaurants only. To compare average ratings fairly, only
# combinations with **at least 20 rated restaurants** are compared; a Kruskal-Wallis test checks whether the differences are larger than chance.

# %%
T2 = L2 / "Task_2_Cuisine_Combination"
cc = df[df["Has_Cuisine"]]
combo = cc.groupby("Cuisine_Combo").agg(Restaurants=("Restaurant ID", "count"), Rated=("Is_Rated", "sum"), Avg_Rating=("Rating", "mean"),
                                        Avg_Votes=("Votes", "mean")).round(3).sort_values("Restaurants", ascending=False)
combo["Share_%"] = (combo["Restaurants"] / len(cc) * 100).round(2)
cz.save_table(combo, T2, "cuisine_combinations_all")
print(f"Distinct combinations: {len(combo):,}; single-cuisine restaurants: {(cc['Cuisine_Count'] == 1).sum():,}; multi-cuisine: {(cc['Cuisine_Count'] > 1).sum():,}")
display(combo.head(10))

MIN_R = 20
q = combo[combo["Rated"] >= MIN_R].sort_values("Avg_Rating", ascending=False)
cz.save_table(q, T2, "combinations_min20_rated")
groups = [cc[(cc["Cuisine_Combo"] == c) & cc["Is_Rated"]]["Rating"].values for c in q.index]
kw = stats.kruskal(*groups)
print(f"{len(q)} combinations have >= {MIN_R} rated restaurants; Kruskal-Wallis H={kw.statistic:.1f}, p={kw.pvalue:.2e}")
display(q.head(8)); display(q.tail(5))

# Pairwise co-occurrence among multi-cuisine restaurants
rows = []
for rid, lst, r in zip(cc["Restaurant ID"], cc["Cuisine_List"], cc["Rating"]):
    for a, b in combinations(lst, 2):
        rows.append((f"{a} + {b}", rid, r))
pairs = pd.DataFrame(rows, columns=["Pair", "id", "Rating"])
pair_tbl = pairs.groupby("Pair").agg(Restaurants=("id", "nunique"), Rated=("Rating", "count"), Avg_Rating=("Rating", "mean")).round(3).sort_values("Restaurants", ascending=False)
cz.save_table(pair_tbl, T2, "cuisine_pairs")
display(pair_tbl.head(8))

by_count = cc.assign(Bucket=cc["Cuisine_Count"].clip(upper=4).map({1: "1 cuisine", 2: "2 cuisines", 3: "3 cuisines", 4: "4+ cuisines"})).groupby("Bucket").agg(
    Restaurants=("Restaurant ID", "count"), Avg_Rating=("Rating", "mean"), Avg_Votes=("Votes", "mean")).round(3)
cz.save_table(by_count, T2, "rating_by_number_of_cuisines")
display(by_count)

# %%
t10 = combo.head(10).iloc[::-1]
fig, ax = cz.new_fig(10, 6.2)
ax.barh(t10.index, t10["Restaurants"], color=BLUE, height=0.62)
cz.label_bars(ax, values=[f"{r:,}  ({s:.1f}%)" for r, s in zip(t10["Restaurants"], t10["Share_%"])], fmt="{}", horizontal=True)
ax.set_xlim(0, t10["Restaurants"].max() * 1.22); ax.set_xlabel("Number of restaurants"); ax.grid(axis="y", visible=False)
cz.titled(fig, f"'{combo.index[0]}' is the most common cuisine listing",
          f"Top 10 exact cuisine combinations (base: {len(cc):,} restaurants with cuisine info)")
cz.save_fig(fig, 2, "L2_T2_top_combinations"); fig

# %%
overall_mean = rated["Rating"].mean()
show = pd.concat([q.head(10), q.tail(10)]).drop_duplicates() if len(q) > 20 else q
show = show.sort_values("Avg_Rating")
fig, ax = cz.new_fig(10.5, 8)
ax.barh([f"{c}  (n={int(n)})" for c, n in zip(show.index, show["Rated"])], show["Avg_Rating"],
        color=[BLUE if v >= overall_mean else ORANGE for v in show["Avg_Rating"]], height=0.62)
cz.label_bars(ax, fmt="{:.2f}", horizontal=True)
ax.axvline(overall_mean, color=INK2, lw=1.4, ls="--"); ax.set_xlim(0, 5.3)
ax.annotate(f"Overall {overall_mean:.2f}", (overall_mean, -0.9), xytext=(5, 0), textcoords="offset points", fontsize=9.5, color=INK2, va="center")
ax.set_xlabel("Average rating (rated restaurants)"); ax.grid(axis="y", visible=False)
cz.titled(fig, "Cuisine combinations differ clearly in average rating",
          f"Highest and lowest 10 of {len(q)} combinations with >= {MIN_R} rated restaurants (blue above overall mean, orange below)")
cz.save_fig(fig, 2, "L2_T2_combination_ratings"); fig

# %%
fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 5.5))
pp = pair_tbl.head(10).iloc[::-1]
a1.barh(pp.index, pp["Restaurants"], color=BLUE, height=0.62); cz.label_bars(a1, horizontal=True)
a1.set_xlim(0, pp["Restaurants"].max() * 1.15); a1.set_title("Most common cuisine pairs (restaurants)", loc="left", fontsize=11, color=INK2); a1.grid(axis="y", visible=False)
a2.bar(by_count.index, by_count["Avg_Rating"], color=BLUE, width=0.6); cz.label_bars(a2, fmt="{:.2f}")
a2.set_ylim(0, 5); a2.set_title("Average rating by number of cuisines listed", loc="left", fontsize=11, color=INK2); a2.grid(axis="x", visible=False)
cz.titled(fig, "Pairings and breadth of cuisine listing", "Left: pairs counted inside multi-cuisine restaurants. Right: rated restaurants only", top=0.80)
cz.save_fig(fig, 2, "L2_T2_pairs_and_breadth"); fig

# %%
hi, lo = q.iloc[0], q.iloc[-1]
obs_c = [
    f"There are {len(combo):,} distinct cuisine combinations. The most common is '{combo.index[0]}' ({combo.iloc[0]['Restaurants']:,.0f} restaurants, {combo.iloc[0]['Share_%']:.1f}%), "
    f"then '{combo.index[1]}' ({combo.iloc[1]['Restaurants']:,.0f}) and '{combo.index[2]}' ({combo.iloc[2]['Restaurants']:,.0f}).",
    f"{(cc['Cuisine_Count'] > 1).mean() * 100:.1f}% of restaurants list more than one cuisine; the most common pair is {pair_tbl.index[0]} ({pair_tbl.iloc[0]['Restaurants']:,.0f} restaurants).",
    f"Among {len(q)} combinations with at least {MIN_R} rated restaurants, average ratings range from {lo['Avg_Rating']:.2f} ('{q.index[-1]}') to {hi['Avg_Rating']:.2f} ('{q.index[0]}').",
    f"The difference between combinations is statistically significant (Kruskal-Wallis H = {kw.statistic:.1f}, p = {kw.pvalue:.1e}), so some combinations really do tend to be rated higher.",
    f"The most popular combination, '{combo.index[0]}', averages {combo.iloc[0]['Avg_Rating']:.2f} vs {overall_mean:.2f} overall - popularity does not guarantee a higher rating.",
    f"By breadth: restaurants with 1 cuisine average {by_count.loc['1 cuisine','Avg_Rating']:.2f}, 2 cuisines {by_count.loc['2 cuisines','Avg_Rating']:.2f}, 3 cuisines {by_count.loc['3 cuisines','Avg_Rating']:.2f}, 4+ cuisines {by_count.loc['4+ cuisines','Avg_Rating']:.2f}.",
    "Caveat: combinations vary strongly by location (e.g. regional cuisines), so differences may partly reflect where those restaurants are, not the cuisine itself.",
]
for o in obs_c: print("-", o)
cz.save_findings(T2, "Level 2 - Task 2: Cuisine Combination", obs_c)
RES["task2"] = {"n_combos": len(combo), "top": combo.head(5).reset_index().to_dict("records"), "best": q.head(5).reset_index().to_dict("records"),
                "worst": q.tail(5).reset_index().to_dict("records"), "kruskal": [kw.statistic, kw.pvalue], "min_rated": MIN_R,
                "n_qualifying": len(q), "by_count": by_count.reset_index().to_dict("records"), "top_pairs": pair_tbl.head(5).reset_index().to_dict("records"),
                "observations": obs_c}

# %% [markdown]
# ---
# ## Task 3 - Geographic Analysis
# * Valid coordinates only: 497 records have (0, 0) placeholders (2 further Indian records lie outside India and are also dropped); India records are also checked against India's bounding box.
# * Outputs: static maps (PNG), an **interactive Folium map** with several switchable layers, and a Plotly density map.
# * Hotspots: DBSCAN (haversine distance, ~700 m radius, min. 20 restaurants) on the Delhi NCR records finds dense clusters objectively.

# %%
T3 = L2 / "Task_3_Geographic_Analysis"
T3.mkdir(exist_ok=True)
geo = df[df["Valid_Coords"]].copy()
in_india = geo["Country"].eq("India")
bad_india = in_india & ~(geo["Latitude"].between(6, 37) & geo["Longitude"].between(68, 98))
geo = geo[~bad_india].copy()
print(f"Mappable restaurants: {len(geo):,} of {len(df):,} (excluded: {len(df) - len(geo):,}; of which (0,0): {clog['placeholder_zero_coordinates']}, outside India box: {int(bad_india.sum())})")
geo_ex = df[~df.index.isin(geo.index)]
print("Excluded by city (top):", geo_ex["City"].value_counts().head(5).to_dict())

# %%
fig, ax = cz.new_fig(11, 6)
ax.scatter(geo["Longitude"], geo["Latitude"], s=5, color=BLUE, alpha=0.35, linewidths=0)
ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude"); ax.set_xlim(-180, 180)
cz.titled(fig, "Restaurants are spread over 15 countries but one cluster dominates",
          f"All {len(geo):,} restaurants with valid coordinates (longitude/latitude)")
cz.save_fig(fig, 2, "L2_T3_world_scatter"); fig

# %%
ncr_cities = ["New Delhi", "Gurgaon", "Noida", "Faridabad", "Ghaziabad"]
ncr = geo[geo["City"].isin(ncr_cities)].copy()
box = ncr[ncr["Longitude"].between(76.8, 77.7) & ncr["Latitude"].between(28.2, 29.0)]
fig, ax = cz.new_fig(10, 8)
hb = ax.hexbin(box["Longitude"], box["Latitude"], gridsize=45, cmap=plt.matplotlib.colors.LinearSegmentedColormap.from_list("b", cz.SEQ_BLUES), mincnt=1, linewidths=0.2)
cb = fig.colorbar(hb, ax=ax, shrink=0.8, pad=0.02); cb.set_label("Restaurants per hexagon"); cb.outline.set_visible(False)
ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude"); ax.set_aspect(1 / np.cos(np.radians(28.6)))
cz.titled(fig, "Delhi NCR has several dense pockets rather than one single core",
          f"Hexagonal density of {len(box):,} restaurants in Delhi, Gurgaon, Noida, Faridabad and Ghaziabad", top=0.88)
cz.save_fig(fig, 2, "L2_T3_ncr_density_hexbin"); fig

# %%
from sklearn.cluster import DBSCAN
EPS_KM, MIN_S = 0.7, 20
coords = np.radians(box[["Latitude", "Longitude"]].values)
db = DBSCAN(eps=EPS_KM / 6371.0088, min_samples=MIN_S, metric="haversine", algorithm="ball_tree").fit(coords)
box = box.assign(Cluster=db.labels_)
clustered = box[box["Cluster"] >= 0]
cl = clustered.groupby("Cluster").agg(Restaurants=("Restaurant ID", "count"), Lat=("Latitude", "mean"), Lon=("Longitude", "mean"),
                                     Avg_Rating=("Rating", "mean"), Main_Locality=("Locality", lambda s: s.mode().iloc[0]),
                                     Main_City=("City", lambda s: s.mode().iloc[0])).round(4).sort_values("Restaurants", ascending=False)
cl = cl.reset_index(drop=True); cl.index = cl.index + 1; cl.index.name = "Hotspot rank"
cz.save_table(cl, T3, "dbscan_hotspots")
print(f"DBSCAN: {len(cl)} dense clusters containing {len(clustered):,} of {len(box):,} NCR restaurants ({len(clustered) / len(box) * 100:.1f}%); noise {int((db.labels_ == -1).sum()):,}")
display(cl.head(10))

loc = geo.groupby(["Locality", "City"]).agg(Restaurants=("Restaurant ID", "count"), Avg_Rating=("Rating", "mean")).round(2).sort_values("Restaurants", ascending=False)
cz.save_table(loc.head(30), T3, "top_localities")
city_geo = geo.groupby("City").agg(Restaurants=("Restaurant ID", "count"), Lat=("Latitude", "median"), Lon=("Longitude", "median"), Avg_Rating=("Rating", "mean")).round(3)
display(loc.head(10))

# %%
lo10 = loc.head(12).iloc[::-1]
fig, ax = cz.new_fig(10, 6.5)
ax.barh([f"{a}, {b}" for a, b in lo10.index], lo10["Restaurants"], color=BLUE, height=0.62)
cz.label_bars(ax, horizontal=True); ax.set_xlim(0, lo10["Restaurants"].max() * 1.12); ax.set_xlabel("Number of restaurants"); ax.grid(axis="y", visible=False)
cz.titled(fig, f"{loc.index[0][0]} is the densest locality", "Top 12 localities by number of restaurants (valid coordinates)")
cz.save_fig(fig, 2, "L2_T3_top_localities"); fig

# %%
import folium
from folium.plugins import MarkerCluster, HeatMap, MiniMap, Fullscreen

def band_color(r):
    if pd.isna(r): return "#8a8985"
    return "#eb6834" if r < 3.0 else "#2a78d6" if r < 4.0 else "#1baf7a"

m = folium.Map(location=[22.5, 79.0], zoom_start=5, tiles="OpenStreetMap", control_scale=True)
Fullscreen().add_to(m); MiniMap(toggle_display=True).add_to(m)

mc = MarkerCluster(name="Restaurants (clustered, colour = rating)", control=True, show=True).add_to(m)
for r in geo.itertuples():
    rating_txt = f"{r.Rating:.1f}" if pd.notna(r.Rating) else "not rated"
    folium.CircleMarker([r.Latitude, r.Longitude], radius=5, color=band_color(r.Rating), weight=1, fill=True, fill_color=band_color(r.Rating), fill_opacity=0.8,
                        tooltip=f"{r._2}",  # Restaurant Name
                        popup=folium.Popup(f"<b>{r._2}</b><br>{r.Cuisines}<br>Rating: {rating_txt} | Votes: {r.Votes}<br>{r.City}", max_width=260)).add_to(mc)

HeatMap(geo[["Latitude", "Longitude"]].values.tolist(), name="Density heat map", radius=9, blur=12, show=False).add_to(m)

fg_city = folium.FeatureGroup(name="City summary (size = restaurants, colour = avg rating)", show=False)
for name, r in city_geo.iterrows():
    folium.CircleMarker([r.Lat, r.Lon], radius=4 + np.sqrt(r.Restaurants) / 2.2, color=band_color(r.Avg_Rating), fill=True, fill_opacity=0.55, weight=1,
                        tooltip=f"{name}: {int(r.Restaurants)} restaurants, avg rating {r.Avg_Rating:.2f}").add_to(fg_city)
fg_city.add_to(m)

fg_hot = folium.FeatureGroup(name="Delhi NCR hotspots (DBSCAN)", show=False)
for rank, r in cl.iterrows():
    folium.Circle([r.Lat, r.Lon], radius=500 + r.Restaurants * 3, color="#0b0b0b", weight=1.5, fill=True, fill_color="#eb6834", fill_opacity=0.25,
                  tooltip=f"Hotspot #{rank}: {r.Main_Locality} ({int(r.Restaurants)} restaurants, avg rating {r.Avg_Rating:.2f})").add_to(fg_hot)
fg_hot.add_to(m)
folium.LayerControl(collapsed=False).add_to(m)
legend = """<div style="position: fixed; bottom: 28px; left: 28px; z-index: 9999; background: #fcfcfb; padding: 10px 14px; border: 1px solid #ccc; border-radius: 6px; font: 12px sans-serif;">
<b>Rating</b><br><span style="color:#eb6834">&#9679;</span> below 3.0 &nbsp; <span style="color:#2a78d6">&#9679;</span> 3.0-3.9 &nbsp; <span style="color:#1baf7a">&#9679;</span> 4.0+ &nbsp; <span style="color:#8a8985">&#9679;</span> not rated</div>"""
m.get_root().html.add_child(folium.Element(legend))
m.save(T3 / "restaurant_map.html")
(cz.VIZ_DIR / "Level_2").mkdir(parents=True, exist_ok=True)
m.save(cz.VIZ_DIR / "Level_2" / "L2_T3_interactive_map.html")
print("Folium map saved:", (T3 / "restaurant_map.html").stat().st_size // 1024, "KB")

# Zoomed Delhi NCR map (lighter file, easier to open)
m2 = folium.Map(location=[28.58, 77.2], zoom_start=10, tiles="OpenStreetMap")
HeatMap(box[["Latitude", "Longitude"]].values.tolist(), radius=8, blur=12).add_to(m2)
for rank, r in cl.head(15).iterrows():
    folium.Marker([r.Lat, r.Lon], tooltip=f"#{rank} {r.Main_Locality}: {int(r.Restaurants)} restaurants").add_to(m2)
m2.save(T3 / "delhi_ncr_heatmap.html")

# %%
try:
    import plotly.express as px
    fn = getattr(px, "density_map", None) or px.density_mapbox
    kw_map = dict(lat="Latitude", lon="Longitude", radius=8, center={"lat": 28.6, "lon": 77.2}, zoom=8, hover_name="Restaurant Name", height=650,
                  title="Restaurant density - Delhi NCR (interactive)")
    fig_p = fn(box, **kw_map, **({"map_style": "open-street-map"} if hasattr(px, "density_map") else {"mapbox_style": "open-street-map"}))
    fig_p.write_html(T3 / "plotly_density_map.html", include_plotlyjs="cdn")
    print("Plotly map saved")
except Exception as e:  # keep the pipeline running; the Folium map is the primary deliverable
    print("Plotly map skipped:", type(e).__name__, e)

# %%
top_hot = cl.iloc[0]
share_ncr = geo["City"].isin(ncr_cities).mean() * 100
obs_g = [
    f"{len(geo):,} of {len(df):,} restaurants ({len(geo) / len(df) * 100:.1f}%) have usable coordinates; {clog['placeholder_zero_coordinates']} have (0, 0) placeholders and are not plotted "
    f"({geo_ex['City'].value_counts().index[0]} accounts for the most excluded records).",
    f"Delhi NCR (New Delhi, Gurgaon, Noida, Faridabad, Ghaziabad) holds {share_ncr:.1f}% of the mappable restaurants, producing one very dense cluster in northern India.",
    f"DBSCAN (radius 700 m, min. 20 restaurants) finds {len(cl)} dense hotspots covering {len(clustered) / len(box) * 100:.1f}% of NCR restaurants. "
    f"The largest cluster is centred near {top_hot['Main_Locality']} ({top_hot['Main_City']}) with {int(top_hot['Restaurants'])} restaurants; DBSCAN chains neighbouring dense areas, so this is a broad contiguous belt of south/central Delhi rather than a single locality.",
    f"Most restaurant-dense localities: {loc.index[0][0]} ({int(loc.iloc[0]['Restaurants'])}), {loc.index[1][0]} ({int(loc.iloc[1]['Restaurants'])}) and {loc.index[2][0]} ({int(loc.iloc[2]['Restaurants'])}).",
    "Outside India the dataset holds mostly ~20 restaurants per city, so those points form small isolated groups around each city rather than genuine density patterns.",
    "Interactive outputs: restaurant_map.html (clustered markers coloured by rating, heat map, city bubbles, hotspot circles, layer control) and delhi_ncr_heatmap.html.",
]
for o in obs_g: print("-", o)
cz.save_findings(T3, "Level 2 - Task 3: Geographic Analysis", obs_g)
RES["task3"] = {"mappable": len(geo), "excluded": len(df) - len(geo), "ncr_share": share_ncr, "n_hotspots": len(cl), "hotspot_cov": len(clustered) / len(box) * 100,
                "hotspots": cl.head(5).reset_index().to_dict("records"), "top_localities": loc.head(5).reset_index().to_dict("records"), "observations": obs_g}

# %% [markdown]
# ---
# ## Task 4 - Restaurant Chains
# **Definition used:** a *chain* is a restaurant name (case-insensitive) that appears in **two or more records**; a *major chain* has **at least 10 outlets**.
# The dataset has no brand-ID column, so name matching is the only available method (limitation: unrelated restaurants can share a name,
# and spelling variants such as "Giani" / "Giani's" count separately).
# Ratings use rated outlets only; popularity = total votes and average votes per outlet.

# %%
T4 = L2 / "Task_4_Restaurant_Chains"
name_counts = df.groupby("Chain_Key").agg(Name=("Restaurant Name", lambda s: s.mode().iloc[0]), Outlets=("Restaurant ID", "count"), Cities=("City", "nunique"),
                                          Rated=("Is_Rated", "sum"), Avg_Rating=("Rating", "mean"), Median_Rating=("Rating", "median"),
                                          Total_Votes=("Votes", "sum"), Avg_Votes=("Votes", "mean"))
name_counts["Is_Chain"] = name_counts["Outlets"] >= 2
chains = name_counts[name_counts["Is_Chain"]].sort_values("Outlets", ascending=False)
major = chains[chains["Outlets"] >= 10].copy()
major_r = major[major["Rated"] >= 5].copy()
major_r["Rating_rank"] = major_r["Avg_Rating"].rank(ascending=False, method="min").astype(int)
major_r["Popularity_rank"] = major_r["Avg_Votes"].rank(ascending=False, method="min").astype(int)
med_r, med_v = major_r["Avg_Rating"].median(), major_r["Avg_Votes"].median()
def quadrant(r):
    return ("Higher rating, more votes" if r.Avg_Rating >= med_r and r.Avg_Votes >= med_v else
            "Higher rating, fewer votes" if r.Avg_Rating >= med_r else
            "Lower rating, more votes" if r.Avg_Votes >= med_v else "Lower rating, fewer votes")
major_r["Performance_group"] = major_r.apply(quadrant, axis=1)
out_cols = ["Name", "Outlets", "Cities", "Rated", "Avg_Rating", "Median_Rating", "Total_Votes", "Avg_Votes", "Rating_rank", "Popularity_rank", "Performance_group"]
chains_out = chains.assign(Avg_Rating=chains["Avg_Rating"].round(3), Avg_Votes=chains["Avg_Votes"].round(1))
cz.save_table(chains_out[["Name", "Outlets", "Cities", "Rated", "Avg_Rating", "Total_Votes", "Avg_Votes"]], T4, "all_chains", index=False)
cz.save_table(major_r[out_cols].round(3).sort_values("Outlets", ascending=False), T4, "major_chains_performance", index=False)

n_single = int((~name_counts["Is_Chain"]).sum())
print(f"Distinct names: {len(name_counts):,} | chains (>=2 outlets): {len(chains)} covering {int(chains['Outlets'].sum()):,} restaurants ({chains['Outlets'].sum() / len(df) * 100:.1f}%) | major (>=10): {len(major)} | single-outlet names: {n_single:,}")
display(chains.head(10)[["Name", "Outlets", "Cities", "Rated", "Avg_Rating", "Total_Votes", "Avg_Votes"]].round(2))

is_chain = df["Chain_Key"].map(name_counts["Is_Chain"])
cmp = df.groupby(is_chain.map({True: "Chain outlets", False: "Independent (unique name)"})).agg(Restaurants=("Restaurant ID", "count"), Avg_Rating=("Rating", "mean"), Avg_Votes=("Votes", "mean"), Median_Votes=("Votes", "median")).round(3)
cz.save_table(cmp, T4, "chains_vs_independents")
display(cmp)
a = df.loc[is_chain & df["Is_Rated"], "Rating"]; b = df.loc[~is_chain & df["Is_Rated"], "Rating"]
mw = stats.mannwhitneyu(a, b); print(f"Chain vs independent rating: {a.mean():.3f} vs {b.mean():.3f}, Mann-Whitney p = {mw.pvalue:.2e}")
display(major_r.sort_values("Avg_Rating", ascending=False)[["Name", "Outlets", "Avg_Rating", "Avg_Votes", "Performance_group"]].round(2).head(8))
display(major_r.sort_values("Avg_Rating")[["Name", "Outlets", "Avg_Rating", "Avg_Votes", "Performance_group"]].round(2).head(5))

# %%
t15 = chains.head(15).iloc[::-1]
fig, ax = cz.new_fig(10, 7)
ax.barh(t15["Name"], t15["Outlets"], color=BLUE, height=0.62); cz.label_bars(ax, horizontal=True)
ax.set_xlim(0, t15["Outlets"].max() * 1.1); ax.set_xlabel("Number of outlets in the dataset"); ax.grid(axis="y", visible=False)
cz.titled(fig, f"{chains.iloc[0]['Name']} and {chains.iloc[1]['Name']} have the most outlets",
          f"Top 15 restaurant chains by outlet count ({len(chains)} names appear at least twice)")
cz.save_fig(fig, 2, "L2_T4_top_chains_outlets"); fig

# %%
rr = major_r.sort_values("Avg_Rating").tail(20) if len(major_r) > 20 else major_r.sort_values("Avg_Rating")
rr_all = pd.concat([major_r.sort_values("Avg_Rating").head(0), rr])
fig, ax = cz.new_fig(10, 7.5)
ax.barh(rr["Name"], rr["Avg_Rating"], color=[BLUE if v >= rated["Rating"].mean() else ORANGE for v in rr["Avg_Rating"]], height=0.62)
cz.label_bars(ax, values=[f"{v:.2f} ({int(o)} outlets)" for v, o in zip(rr["Avg_Rating"], rr["Outlets"])], fmt="{}", horizontal=True)
ax.axvline(rated["Rating"].mean(), color=INK2, lw=1.4, ls="--"); ax.set_xlim(0, 5.5)
ax.annotate(f"All rated: {rated['Rating'].mean():.2f}", (rated["Rating"].mean(), len(rr) - 0.2), xytext=(5, 0), textcoords="offset points", fontsize=9.5, color=INK2, va="center")
ax.set_xlabel("Average rating (rated outlets)"); ax.grid(axis="y", visible=False)
cz.titled(fig, f"Chain ratings vary widely: {major_r['Avg_Rating'].min():.2f} to {major_r['Avg_Rating'].max():.2f}",
          f"Average rating of major chains (>= 10 outlets, >= 5 rated; top {len(rr)} shown; blue above overall mean, orange below)")
cz.save_fig(fig, 2, "L2_T4_chain_ratings"); fig

# %%
fig, ax = cz.new_fig(10.5, 7)
cols = major_r["Performance_group"].map({"Higher rating, more votes": BLUE, "Higher rating, fewer votes": AQUA, "Lower rating, more votes": ORANGE, "Lower rating, fewer votes": MUTED})
ax.scatter(major_r["Avg_Rating"], major_r["Avg_Votes"], s=major_r["Outlets"] * 6, c=cols, alpha=0.85, edgecolor=cz.SURFACE, linewidth=1.5)
ax.set_yscale("log"); ax.axvline(med_r, color=MUTED, lw=1, ls="--"); ax.axhline(med_v, color=MUTED, lw=1, ls="--")
for _, r in major_r.sort_values("Outlets", ascending=False).head(10).iterrows():
    ax.annotate(r["Name"], (r["Avg_Rating"], r["Avg_Votes"]), xytext=(7, 5), textcoords="offset points", fontsize=9, color=INK2)
from matplotlib.lines import Line2D
ax.legend(handles=[Line2D([0], [0], marker="o", color="none", markerfacecolor=c, markersize=9, label=l) for l, c in
                   [("Higher rating, more votes", BLUE), ("Higher rating, fewer votes", AQUA), ("Lower rating, more votes", ORANGE), ("Lower rating, fewer votes", MUTED)]],
          loc="lower right", fontsize=9)
ax.set_xlabel("Average rating (rated outlets)"); ax.set_ylabel("Average votes per outlet (log scale)")
cz.titled(fig, "Rating vs popularity for major chains", f"Bubble size = number of outlets; dashed lines = medians across {len(major_r)} major chains")
cz.save_fig(fig, 2, "L2_T4_rating_vs_popularity"); fig

# %%
best, worst = major_r.sort_values("Avg_Rating", ascending=False).iloc[0], major_r.sort_values("Avg_Rating").iloc[0]
pop = major_r.sort_values("Avg_Votes", ascending=False).iloc[0]
top_votes_chain = chains.sort_values("Total_Votes", ascending=False).iloc[0]
obs_ch = [
    f"Yes - chains exist: {len(chains)} restaurant names appear at least twice, covering {int(chains['Outlets'].sum()):,} restaurants ({chains['Outlets'].sum() / len(df) * 100:.1f}% of the dataset); {len(major)} have 10 or more outlets.",
    f"Largest chains by outlets: {chains.iloc[0]['Name']} ({int(chains.iloc[0]['Outlets'])}), {chains.iloc[1]['Name']} ({int(chains.iloc[1]['Outlets'])}), {chains.iloc[2]['Name']} ({int(chains.iloc[2]['Outlets'])}), "
    f"{chains.iloc[3]['Name']} ({int(chains.iloc[3]['Outlets'])}) and {chains.iloc[4]['Name']} ({int(chains.iloc[4]['Outlets'])}).",
    f"Among major chains (>= 10 outlets, >= 5 rated), the highest average rating is {best['Name']} ({best['Avg_Rating']:.2f}, {int(best['Outlets'])} outlets) and the lowest is {worst['Name']} ({worst['Avg_Rating']:.2f}, {int(worst['Outlets'])} outlets).",
    f"Most popular by average votes per outlet: {pop['Name']} ({pop['Avg_Votes']:.0f}); most total votes across all outlets: {top_votes_chain['Name']} ({int(top_votes_chain['Total_Votes']):,}).",
    f"Chain outlets average {cmp.loc['Chain outlets','Avg_Rating']:.2f} vs {cmp.loc['Independent (unique name)','Avg_Rating']:.2f} for restaurants with a unique name (Mann-Whitney p = {mw.pvalue:.1e}); "
    f"average votes {cmp.loc['Chain outlets','Avg_Votes']:.0f} vs {cmp.loc['Independent (unique name)','Avg_Votes']:.0f}.",
    f"Performance groups (medians as cut-offs): " + "; ".join(f"{k}: {v}" for k, v in major_r['Performance_group'].value_counts().items()) + ".",
    "Caveat: chains are detected by identical names; unrelated restaurants sharing a name, and spelling variants, cannot be separated with the available columns.",
]
for o in obs_ch: print("-", o)
cz.save_findings(T4, "Level 2 - Task 4: Restaurant Chains", obs_ch)
RES["task4"] = {"n_chains": len(chains), "chain_outlets": int(chains["Outlets"].sum()), "n_major": len(major), "top": chains.head(5)[["Name", "Outlets", "Avg_Rating", "Avg_Votes"]].reset_index(drop=True).round(2).to_dict("records"),
                "best": best[["Name", "Outlets", "Avg_Rating", "Avg_Votes"]].to_dict(), "worst": worst[["Name", "Outlets", "Avg_Rating", "Avg_Votes"]].to_dict(),
                "compare": cmp.reset_index().to_dict("records"), "p": mw.pvalue, "groups": major_r["Performance_group"].value_counts().to_dict(), "observations": obs_ch}

# %%
cz.dump_results(2, RES)
print("Level 2 complete. Files:", sorted(p.name for p in (cz.VIZ_DIR / "Level_2").iterdir()))
