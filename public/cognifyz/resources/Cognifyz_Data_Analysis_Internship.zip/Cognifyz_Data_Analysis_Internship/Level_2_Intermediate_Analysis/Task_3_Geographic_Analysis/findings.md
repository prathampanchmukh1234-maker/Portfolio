# Level 2 - Task 3: Geographic Analysis

- 9,052 of 9,551 restaurants (94.8%) have usable coordinates; 497 have (0, 0) placeholders and are not plotted (New Delhi accounts for the most excluded records).
- Delhi NCR (New Delhi, Gurgaon, Noida, Faridabad, Ghaziabad) holds 83.4% of the mappable restaurants, producing one very dense cluster in northern India.
- DBSCAN (radius 700 m, min. 20 restaurants) finds 56 dense hotspots covering 87.7% of NCR restaurants. The largest cluster is centred near Defence Colony (New Delhi) with 1046 restaurants; DBSCAN chains neighbouring dense areas, so this is a broad contiguous belt of south/central Delhi rather than a single locality.
- Most restaurant-dense localities: Connaught Place (122), Rajouri Garden (98) and Defence Colony (85).
- Outside India the dataset holds mostly ~20 restaurants per city, so those points form small isolated groups around each city rather than genuine density patterns.
- Interactive outputs: restaurant_map.html (clustered markers coloured by rating, heat map, city bubbles, hotspot circles, layer control) and delhi_ncr_heatmap.html.
