# Level 2 - Task 2: Cuisine Combination

- There are 1,339 distinct cuisine combinations. The most common is 'North Indian' (936 restaurants, 9.8%), then 'Chinese, North Indian' (616) and 'Mughlai, North Indian' (395).
- 64.4% of restaurants list more than one cuisine; the most common pair is Chinese + North Indian (1,782 restaurants).
- Among 52 combinations with at least 20 rated restaurants, average ratings range from 2.99 ('Fast Food, Raw Meats') to 4.06 ('Japanese, Sushi').
- The difference between combinations is statistically significant (Kruskal-Wallis H = 705.7, p = 5.3e-116), so some combinations really do tend to be rated higher.
- The most popular combination, 'North Indian', averages 3.18 vs 3.44 overall - popularity does not guarantee a higher rating.
- By breadth: restaurants with 1 cuisine average 3.40, 2 cuisines 3.39, 3 cuisines 3.49, 4+ cuisines 3.61.
- Caveat: combinations vary strongly by location (e.g. regional cuisines), so differences may partly reflect where those restaurants are, not the cuisine itself.
