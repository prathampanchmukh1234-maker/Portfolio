# %% [markdown]
# # Cognifyz Technologies - Data Analysis Internship
# ## Level 3: Advanced Data Analysis
# Tasks: (1) Restaurant Reviews, (2) Votes Analysis, (3) Price Range vs Online Delivery and Table Booking.
#
# **Important data finding:** the dataset contains **no review text**, so Task 1 cannot be performed on real data.
# It is documented as *Blocked - Missing Data* with an audit proving it; nothing is invented.

# %%
import sys
from pathlib import Path
try:
    HERE = Path(__file__).resolve().parent
except NameError:
    HERE = Path.cwd()
sys.path.insert(0, str(HERE.parent))

import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
import common as cz
from common import BLUE, ORANGE, AQUA, INK, INK2, MUTED, FADED, GRID

try:
    from IPython.display import display
except ImportError:
    display = print
pd.set_option("display.width", 150)
L3 = HERE
RES = {}
df, clog = cz.load_clean(save=False)
rated = df[df["Is_Rated"]]

# %% [markdown]
# ---
# ## Task 1 - Restaurant Reviews (data-availability audit)
# The task needs free-text reviews. This audit inspects **every** text column of the dataset and tests whether any could hold
# review text (long, mostly unique sentences). Only genuinely review-like data may be used; otherwise the task is blocked.

# %%
T1 = L3 / "Task_1_Restaurant_Reviews"
raw = cz.load_raw()
rows = []
for col in raw.columns:
    s = raw[col]
    if pd.api.types.is_string_dtype(s) or s.dtype == object:
        t = s.dropna().astype(str)
        words = t.str.split().str.len()
        rows.append({"Column": col, "Distinct values": t.nunique(), "Distinct ratio": round(t.nunique() / len(t), 3),
                     "Avg characters": round(t.str.len().mean(), 1), "Avg words": round(words.mean(), 2), "Max words": int(words.max()),
                     "Example value": t.iloc[0][:45]})
audit = pd.DataFrame(rows).sort_values("Avg words", ascending=False)
# A review-like column would typically have >= ~10 words on average and a high share of distinct values
audit["Looks like review text?"] = np.where((audit["Avg words"] >= 10) & (audit["Distinct ratio"] > 0.5), "Yes", "No")
cz.save_table(audit, T1, "text_column_audit", index=False)
display(audit)
review_like = audit[audit["Looks like review text?"] == "Yes"]
keyword_cols = [c for c in raw.columns if any(k in c.lower() for k in ("review", "comment", "feedback", "text", "opinion"))]
print("Review-like columns:", review_like["Column"].tolist() or "NONE")
print("Columns whose NAME suggests review text:", keyword_cols)
print("Rating text values (a 6-value rating LABEL, not a review):", sorted(raw["Rating text"].unique()))

# %%
obs_rev = [
    f"Audit of all {len(audit)} text columns: none contains review text. The longest column averages {audit['Avg words'].iloc[0]:.1f} words ({audit['Column'].iloc[0]}), "
    f"far below the length of a review, and no column name refers to reviews or comments.",
    "'Rating text' holds only 6 fixed labels (" + ", ".join(sorted(raw["Rating text"].unique())) + ") - it is a category derived from the numeric rating, not a customer review.",
    "Consequently, positive/negative keywords, average review length and the review-length vs rating relationship CANNOT be computed from this dataset. "
    "No reviews or keywords have been invented.",
    "Exact next action: obtain a restaurant-review dataset that includes review text per restaurant (for example from the internship coordinators at Cognifyz, or the "
    "original source of this dataset), join it on Restaurant ID, and run review_analysis_template.py in this folder.",
]
for o in obs_rev: print("-", o)
cz.save_findings(T1, "Level 3 - Task 1: Restaurant Reviews (BLOCKED - missing data)", obs_rev)
RES["task1"] = {"status": "Blocked - Missing Data", "audit": audit.drop(columns=["Example value"]).to_dict("records"), "observations": obs_rev}

# %% [markdown]
# ---
# ## Task 2 - Votes Analysis
# * Highest and lowest vote counts (ties are reported, because many restaurants share the minimum).
# * Correlation between votes and rating. Votes are extremely skewed, so Pearson (linear), Spearman (rank) and Pearson on log(votes) are all reported.
# * Restaurants with 0 votes are unrated (rating 0 means "not rated"), so the main correlation uses rated restaurants only.

# %%
T2 = L3 / "Task_2_Votes_Analysis"
hi = df.sort_values("Votes", ascending=False).head(10)[["Restaurant Name", "City", "Locality", "Cuisines", "Votes", "Aggregate rating"]]
n_zero = int((df["Votes"] == 0).sum())
zero_all_unrated = bool(df.loc[df["Votes"] == 0, "Aggregate rating"].eq(0).all())
lo_rated = rated.sort_values("Votes").head(10)[["Restaurant Name", "City", "Votes", "Aggregate rating"]]
min_pos = df.loc[df["Votes"] > 0, "Votes"].min()
cz.save_table(hi, T2, "top10_most_voted", index=False)
cz.save_table(lo_rated, T2, "lowest_votes_among_rated", index=False)
print(f"Highest: {hi.iloc[0]['Restaurant Name']} ({hi.iloc[0]['City']}) {hi.iloc[0]['Votes']:,} votes, rating {hi.iloc[0]['Aggregate rating']}")
print(f"Lowest: {n_zero:,} restaurants tie at 0 votes; all unrated: {zero_all_unrated}; lowest positive votes: {min_pos}; lowest among rated: {rated['Votes'].min()}")
display(hi); display(lo_rated.head(5))

def corr_row(name, x, y):
    pr = stats.pearsonr(x, y); sp = stats.spearmanr(x, y)
    return {"Sample": name, "n": len(x), "Pearson r": round(pr[0], 3), "Pearson p": pr[1], "Spearman rho": round(sp[0], 3), "Spearman p": sp[1]}
cr = pd.DataFrame([
    corr_row("Rated restaurants - votes vs rating", rated["Votes"], rated["Rating"]),
    corr_row("Rated restaurants - log(1+votes) vs rating", np.log1p(rated["Votes"]), rated["Rating"]),
    corr_row("All restaurants (0 = unrated included)", df["Votes"], df["Aggregate rating"]),
])
cz.save_table(cr, T2, "correlation_results", index=False)
display(cr)
ncr_rated = rated[rated["City"].isin(["New Delhi", "Gurgaon", "Noida", "Faridabad", "Ghaziabad"])]
cr_ncr = corr_row("Delhi NCR rated only (spearman check)", ncr_rated["Votes"], ncr_rated["Rating"])
print("Delhi NCR only:", cr_ncr)

edges = [1.5, 2.5, 3.0, 3.5, 4.0, 4.5, 5.01]; lbl = ["<2.5", "2.5-2.9", "3.0-3.4", "3.5-3.9", "4.0-4.4", "4.5+"]
rated = rated.assign(Band=pd.cut(rated["Rating"], edges, labels=lbl, right=False))
band_votes = rated.groupby("Band", observed=True)["Votes"].agg(["count", "mean", "median"]).round(1)
cz.save_table(band_votes, T2, "votes_by_rating_band")
display(band_votes)

# %%
fig, ax = cz.new_fig(10, 6.5)
jit = rated["Rating"] + np.random.default_rng(42).uniform(-0.04, 0.04, len(rated))
ax.scatter(rated["Votes"], jit, s=7, color=BLUE, alpha=0.28, linewidths=0)
ax.set_xscale("log")
bins = np.logspace(np.log10(rated["Votes"].min()), np.log10(rated["Votes"].max()), 14)
rated_b = rated.assign(vb=pd.cut(rated["Votes"], bins))
mid = rated_b.groupby("vb", observed=True).agg(v=("Votes", "median"), r=("Rating", "mean"))
ax.plot(mid["v"], mid["r"], color=ORANGE, lw=2.4, marker="o", ms=6, markeredgecolor=cz.SURFACE, label="Average rating per vote band")
ax.legend(loc="lower right"); ax.set_xlabel("Votes (log scale)"); ax.set_ylabel("Aggregate rating")
rho = cr.iloc[0]["Spearman rho"]
cz.titled(fig, f"More-voted restaurants tend to have higher ratings (Spearman rho = {rho:.2f})",
          f"Votes vs aggregate rating, {len(rated):,} rated restaurants (small vertical jitter added for visibility)")
cz.save_fig(fig, 3, "L3_T2_votes_vs_rating_scatter"); fig

# %%
fig, ax = cz.new_fig(10, 6)
data = [rated.loc[rated["Band"] == b, "Votes"] for b in lbl]
bp = ax.boxplot(data, tick_labels=lbl, patch_artist=True, widths=0.55, medianprops={"color": INK, "lw": 2}, flierprops={"markersize": 2.5, "markeredgecolor": MUTED})
for p in bp["boxes"]: p.set(facecolor=FADED, edgecolor=BLUE)
ax.set_yscale("log"); ax.set_xlabel("Aggregate rating range"); ax.set_ylabel("Votes (log scale)"); ax.grid(axis="x", visible=False)
cz.titled(fig, "Median votes climb sharply for restaurants rated 3.5 and above", "Distribution of votes by rating band, rated restaurants")
cz.save_fig(fig, 3, "L3_T2_votes_by_rating_band"); fig

# %%
top = hi.head(10).iloc[::-1]
fig, ax = cz.new_fig(10, 6.2)
ax.barh([f"{n} ({c})" for n, c in zip(top["Restaurant Name"], top["City"])], top["Votes"], color=BLUE, height=0.62)
cz.label_bars(ax, values=[f"{v:,}  (rating {r})" for v, r in zip(top["Votes"], top["Aggregate rating"])], fmt="{}", horizontal=True)
ax.set_xlim(0, top["Votes"].max() * 1.28); cz.thousands(ax, "x"); ax.set_xlabel("Votes"); ax.grid(axis="y", visible=False)
cz.titled(fig, f"{hi.iloc[0]['Restaurant Name']} is the most-voted restaurant", "Top 10 restaurants by number of votes")
cz.save_fig(fig, 3, "L3_T2_top_voted_restaurants"); fig

# %%
r1, r2, r3 = cr.iloc[0], cr.iloc[1], cr.iloc[2]
strength = lambda v: "weak" if abs(v) < 0.3 else "moderate" if abs(v) < 0.6 else "strong"
obs_v = [
    f"Highest votes: {hi.iloc[0]['Restaurant Name']} ({hi.iloc[0]['City']}) with {hi.iloc[0]['Votes']:,} votes (rating {hi.iloc[0]['Aggregate rating']}), followed by {hi.iloc[1]['Restaurant Name']} ({hi.iloc[1]['Votes']:,}) and {hi.iloc[2]['Restaurant Name']} ({hi.iloc[2]['Votes']:,}).",
    f"Lowest votes: {n_zero:,} restaurants tie at 0 votes (all of them unrated: {zero_all_unrated}), so there is no single 'lowest' restaurant. Among rated restaurants the minimum is {rated['Votes'].min()} votes "
    f"({int((rated['Votes'] == rated['Votes'].min()).sum())} restaurants tie).",
    f"Rated restaurants: Pearson r = {r1['Pearson r']:.2f} (p < 0.001) - a {strength(r1['Pearson r'])} linear relationship; Spearman rho = {r1['Spearman rho']:.2f} ({strength(r1['Spearman rho'])}). "
    f"Using log(votes), Pearson r = {r2['Pearson r']:.2f}.",
    f"Including unrated restaurants (rating 0, usually 0 votes) the correlation is {r3['Pearson r']:.2f}, which is inflated by the zeros and is therefore not used for conclusions.",
    f"Median votes by rating band: lowest at {band_votes['median'].min():.0f} ({band_votes['median'].idxmin()}), {band_votes['median'].loc['3.5-3.9']:.0f} for 3.5-3.9, and {band_votes['median'].iloc[-1]:.0f} for 4.5+ - the rise is steep from 3.5 upward (poorly rated restaurants below 2.5 have a slightly higher median than the 2.5-2.9 band, so the pattern is not perfectly monotone).",
    "Interpretation: well-rated restaurants collect more votes. Correlation does not show causation - popular restaurants may be rated by more (and different) people, and highly visible restaurants attract more voters.",
    f"The relationship also holds within Delhi NCR alone (Spearman rho = {cr_ncr['Spearman rho']:.2f}), so it is not just a mix of cities.",
]
for o in obs_v: print("-", o)
cz.save_findings(T2, "Level 3 - Task 2: Votes Analysis", obs_v)
RES["task2"] = {"highest": hi.head(3).to_dict("records"), "n_zero": n_zero, "zero_all_unrated": zero_all_unrated, "min_rated_votes": int(rated["Votes"].min()),
                "corr": cr.to_dict("records"), "ncr_spearman": cr_ncr["Spearman rho"], "band_votes": band_votes.reset_index().to_dict("records"), "observations": obs_v}

# %% [markdown]
# ---
# ## Task 3 - Price Range vs Online Delivery and Table Booking
# For each price range (1-4) the share of restaurants with online delivery and with table booking is computed, then tested with a
# chi-square test of independence (effect size: Cramer's V) and a Spearman rank correlation (price range 1-4 vs Yes/No).
# Online delivery exists only in India and the UAE in this data, so the analysis is repeated for **India only** to avoid a country mix-up.

# %%
T3 = L3 / "Task_3_Price_Delivery_Table_Booking"

def service_table(frame, col):
    ct = pd.crosstab(frame["Price range"], frame[col].map({True: "Yes", False: "No"}))
    out = ct.copy(); out["Total"] = ct.sum(axis=1); out["% with service"] = (ct["Yes"] / out["Total"] * 100).round(2)
    return out

def tests(frame, col):
    ct = pd.crosstab(frame["Price range"], frame[col])
    chi2, p, dof, _ = stats.chi2_contingency(ct)
    v = np.sqrt(chi2 / (ct.values.sum() * (min(ct.shape) - 1)))
    rho, pr = stats.spearmanr(frame["Price range"], frame[col].astype(int))
    return {"chi2": chi2, "p": p, "dof": dof, "cramers_v": v, "spearman_rho": rho, "spearman_p": pr}

scopes = {"All restaurants": df, "India only": df[df["Country"] == "India"]}
tabs, tst = {}, {}
for sname, frame in scopes.items():
    for col, label in (("Has_Delivery", "Online delivery"), ("Has_Booking", "Table booking")):
        t = service_table(frame, col); tabs[(sname, label)] = t; tst[(sname, label)] = tests(frame, col)
        cz.save_table(t, T3, f"{sname.lower().replace(' ', '_')}_{label.lower().replace(' ', '_')}")
        print(f"\n{sname} - {label}"); display(t)
        print({k: (round(v_, 4) if k != 'p' and k != 'spearman_p' else f"{v_:.2e}") for k, v_ in tst[(sname, label)].items()})
test_tbl = pd.DataFrame(tst).T.round(4); test_tbl.index.names = ["Scope", "Service"]
cz.save_table(test_tbl, T3, "statistical_tests")

summary = pd.DataFrame({f"{s} - {l}": tabs[(s, l)]["% with service"] for s, l in tabs})
summary.index.name = "Price range"
cz.save_table(summary, T3, "percentage_summary")
display(summary)

# %%
fig, axes = plt.subplots(1, 2, figsize=(12, 6), sharey=True)
x = np.arange(4); w = 0.36
for ax, sname in zip(axes, scopes):
    d, b = tabs[(sname, "Online delivery")]["% with service"], tabs[(sname, "Table booking")]["% with service"]
    ax.bar(x - w / 2, d, w, color=BLUE, label="Online delivery"); ax.bar(x + w / 2, b, w, color=ORANGE, label="Table booking")
    cz.label_bars(ax, fmt="{:.0f}%", size=9); ax.set_xticks(x, [cz.PRICE_LABELS[i] for i in range(1, 5)])
    ax.set_title(sname, loc="left", fontsize=11, color=INK2); ax.set_xlabel("Price range"); ax.set_ylim(0, 80); ax.grid(axis="x", visible=False)
axes[0].set_ylabel("Share of restaurants offering the service (%)"); axes[0].legend(loc="upper left")
cz.titled(fig, "Table booking rises with price; online delivery peaks in the mid-price tiers",
          "Share of restaurants with each service, by price range (1 = lowest, 4 = highest)", top=0.80)
cz.save_fig(fig, 3, "L3_T3_service_by_price_range"); fig

# %%
# Heat-map style comparison of the full table (India only), counts + percentages
fig, ax = cz.new_fig(9, 5)
mat = summary[["India only - Online delivery", "India only - Table booking", "All restaurants - Online delivery", "All restaurants - Table booking"]].T
im = ax.imshow(mat.values, cmap=plt.matplotlib.colors.LinearSegmentedColormap.from_list("b", cz.SEQ_BLUES), vmin=0, vmax=70, aspect="auto")
ax.set_xticks(range(4), [cz.PRICE_LABELS[i] for i in range(1, 5)]); ax.set_yticks(range(4), [i.replace(" - ", "\n") for i in mat.index]); ax.grid(False)
for i in range(4):
    for j in range(4):
        ax.text(j, i, f"{mat.values[i, j]:.1f}%", ha="center", va="center", color="white" if mat.values[i, j] > 35 else INK, fontsize=10.5)
ax.set_xlabel("Price range"); [s.set_visible(False) for s in ax.spines.values()]
cz.titled(fig, "Service availability by price range", "Percentage of restaurants offering the service (table view of the chart above)")
cz.save_fig(fig, 3, "L3_T3_service_heatmap_table"); fig

# %%
d_all, b_all = tabs[("All restaurants", "Online delivery")]["% with service"], tabs[("All restaurants", "Table booking")]["% with service"]
d_in, b_in = tabs[("India only", "Online delivery")]["% with service"], tabs[("India only", "Table booking")]["% with service"]
peak_d = int(d_in.idxmax())
tb, td = tst[("India only", "Table booking")], tst[("India only", "Online delivery")]
obs_p = [
    f"Online delivery by price range (all restaurants): 1 -> {d_all[1]:.1f}%, 2 -> {d_all[2]:.1f}%, 3 -> {d_all[3]:.1f}%, 4 -> {d_all[4]:.1f}%. "
    f"India only: {d_in[1]:.1f}%, {d_in[2]:.1f}%, {d_in[3]:.1f}%, {d_in[4]:.1f}%.",
    f"Table booking by price range (all restaurants): {b_all[1]:.1f}%, {b_all[2]:.1f}%, {b_all[3]:.1f}%, {b_all[4]:.1f}%. India only: {b_in[1]:.1f}%, {b_in[2]:.1f}%, {b_in[3]:.1f}%, {b_in[4]:.1f}%.",
    f"Are higher-priced restaurants more likely to offer table booking? Yes - clearly. The share rises at every step (Spearman rho = {tb['spearman_rho']:.2f} in India; "
    f"chi-square p < 1e-300, Cramer's V = {tb['cramers_v']:.2f}).",
    f"Are higher-priced restaurants more likely to offer online delivery? Not consistently. Delivery is most common in price range {peak_d} ({d_in[peak_d]:.1f}% in India) and drops for the most expensive tier "
    f"({d_in[4]:.1f}%), even below the cheapest tier ({d_in[1]:.1f}%); the overall rank correlation is small (rho = {td['spearman_rho']:.2f}), although the association is statistically significant (p = {td['p']:.1e}, Cramer's V = {td['cramers_v']:.2f}).",
    f"Range 1 restaurants almost never offer table booking ({b_in[1]:.2f}% in India) but {d_in[1]:.1f}% offer delivery; range 4 restaurants are the opposite - booking-oriented ({b_in[4]:.1f}%) and less delivery-oriented.",
    "Country matters: all non-Indian, non-UAE restaurants have no delivery recorded, which is why 'All restaurants' delivery rates are lower than 'India only'.",
    "These are associations in this dataset's records and do not explain why restaurants choose these services.",
]
for o in obs_p: print("-", o)
cz.save_findings(T3, "Level 3 - Task 3: Price Range vs Online Delivery & Table Booking", obs_p)
RES["task3"] = {"summary": summary.reset_index().to_dict("records"), "tests": {f"{k[0]} | {k[1]}": v for k, v in tst.items()}, "observations": obs_p}

# %%
cz.dump_results(3, RES)
print("Level 3 complete. Files:", sorted(p.name for p in (cz.VIZ_DIR / "Level_3").iterdir()))
