# Level 3 - Task 3: Price Range vs Online Delivery & Table Booking

- Online delivery by price range (all restaurants): 1 -> 15.8%, 2 -> 41.3%, 3 -> 29.2%, 4 -> 9.0%. India only: 16.3%, 44.8%, 35.8%, 11.1%.
- Table booking by price range (all restaurants): 0.0%, 7.7%, 45.7%, 46.8%. India only: 0.0%, 8.2%, 56.2%, 64.7%.
- Are higher-priced restaurants more likely to offer table booking? Yes - clearly. The share rises at every step (Spearman rho = 0.52 in India; chi-square p < 1e-300, Cramer's V = 0.63).
- Are higher-priced restaurants more likely to offer online delivery? Not consistently. Delivery is most common in price range 2 (44.8% in India) and drops for the most expensive tier (11.1%), even below the cheapest tier (16.3%); the overall rank correlation is small (rho = 0.20), although the association is statistically significant (p = 7.5e-169, Cramer's V = 0.30).
- Range 1 restaurants almost never offer table booking (0.02% in India) but 16.3% offer delivery; range 4 restaurants are the opposite - booking-oriented (64.7%) and less delivery-oriented.
- Country matters: all non-Indian, non-UAE restaurants have no delivery recorded, which is why 'All restaurants' delivery rates are lower than 'India only'.
- These are associations in this dataset's records and do not explain why restaurants choose these services.
