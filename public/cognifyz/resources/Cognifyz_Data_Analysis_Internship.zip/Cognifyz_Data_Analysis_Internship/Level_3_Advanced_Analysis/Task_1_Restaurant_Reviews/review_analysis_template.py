"""
review_analysis_template.py  -  READY-TO-USE, BUT NOT YET RUN ON REAL REVIEW DATA

Why this file exists
--------------------
Level 3 / Task 1 needs review TEXT. The supplied Dataset.csv has none (see findings.md in this folder),
so the task is "Blocked - Missing Data". When a review file becomes available, run:

    python review_analysis_template.py reviews.csv

Expected input: a CSV with columns  'Restaurant ID'  and  'Review'  (one row per review).
The script joins it with the restaurant ratings from Dataset/cleaned_dataset.csv and reports:
  * most common positive and negative keywords (simple lexicon method - extend the lexicons for better coverage)
  * average review length (words and characters)
  * relationship between review length and rating (Spearman correlation)
No results are produced unless real review text is supplied.
"""
import re
import sys
from collections import Counter
from pathlib import Path

import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
STOPWORDS = set("a an and are as at be been but by for from had has have i if in is it its me my of on or our so that the their them they this to was we were with you your".split())
POSITIVE = set("good great excellent amazing delicious tasty fresh friendly love loved best awesome nice perfect wonderful superb yummy clean fast recommend".split())
NEGATIVE = set("bad poor terrible awful bland cold slow rude dirty worst disappointing overpriced stale horrible tasteless waste unhygienic late expensive".split())


def preprocess(text: str) -> list:
    """Lower-case, keep letters only, drop stop-words and very short tokens."""
    tokens = re.findall(r"[a-z']+", str(text).lower())
    return [t.strip("'") for t in tokens if len(t) > 2 and t not in STOPWORDS]


def analyse(reviews: pd.DataFrame, restaurants: pd.DataFrame) -> dict:
    reviews = reviews.dropna(subset=["Review"]).copy()
    reviews["tokens"] = reviews["Review"].map(preprocess)
    reviews["words"] = reviews["Review"].astype(str).str.split().str.len()
    reviews["chars"] = reviews["Review"].astype(str).str.len()
    counts = Counter(t for toks in reviews["tokens"] for t in toks)
    merged = reviews.merge(restaurants[["Restaurant ID", "Aggregate rating"]], on="Restaurant ID", how="inner")
    merged = merged[merged["Aggregate rating"] > 0]  # 0 means 'Not rated'
    rho, p = stats.spearmanr(merged["words"], merged["Aggregate rating"]) if len(merged) > 2 else (float("nan"), float("nan"))
    return {
        "top_positive": [(w, c) for w, c in counts.most_common() if w in POSITIVE][:15],
        "top_negative": [(w, c) for w, c in counts.most_common() if w in NEGATIVE][:15],
        "avg_words": reviews["words"].mean(), "avg_chars": reviews["chars"].mean(),
        "length_vs_rating_spearman": (rho, p), "n_reviews": len(reviews), "n_matched": len(merged),
    }


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Usage: python review_analysis_template.py reviews.csv")
    rest = pd.read_csv(ROOT / "Dataset" / "cleaned_dataset.csv")
    rev = pd.read_csv(sys.argv[1])
    missing = {"Restaurant ID", "Review"} - set(rev.columns)
    if missing:
        sys.exit(f"Missing required columns: {missing}")
    for k, v in analyse(rev, rest).items():
        print(f"{k}: {v}")
