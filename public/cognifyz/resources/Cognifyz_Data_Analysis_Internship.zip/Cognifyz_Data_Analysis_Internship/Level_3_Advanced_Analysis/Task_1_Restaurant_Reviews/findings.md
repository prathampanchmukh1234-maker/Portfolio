# Level 3 - Task 1: Restaurant Reviews (BLOCKED - missing data)

- Audit of all 13 text columns: none contains review text. The longest column averages 8.7 words (Address), far below the length of a review, and no column name refers to reviews or comments.
- 'Rating text' holds only 6 fixed labels (Average, Excellent, Good, Not rated, Poor, Very Good) - it is a category derived from the numeric rating, not a customer review.
- Consequently, positive/negative keywords, average review length and the review-length vs rating relationship CANNOT be computed from this dataset. No reviews or keywords have been invented.
- Exact next action: obtain a restaurant-review dataset that includes review text per restaurant (for example from the internship coordinators at Cognifyz, or the original source of this dataset), join it on Restaurant ID, and run review_analysis_template.py in this folder.
