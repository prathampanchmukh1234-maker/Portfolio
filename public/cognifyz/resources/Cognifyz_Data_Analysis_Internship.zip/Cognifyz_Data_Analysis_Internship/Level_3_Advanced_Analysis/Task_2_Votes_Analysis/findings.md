# Level 3 - Task 2: Votes Analysis

- Highest votes: Toit (Bangalore) with 10,934 votes (rating 4.8), followed by Truffles (9,667) and Hauz Khas Social (7,931).
- Lowest votes: 1,094 restaurants tie at 0 votes (all of them unrated: True), so there is no single 'lowest' restaurant. Among rated restaurants the minimum is 4 votes (207 restaurants tie).
- Rated restaurants: Pearson r = 0.41 (p < 0.001) - a moderate linear relationship; Spearman rho = 0.68 (strong). Using log(votes), Pearson r = 0.65.
- Including unrated restaurants (rating 0, usually 0 votes) the correlation is 0.31, which is inflated by the zeros and is therefore not used for conclusions.
- Median votes by rating band: lowest at 16 (2.5-2.9), 121 for 3.5-3.9, and 489 for 4.5+ - the rise is steep from 3.5 upward (poorly rated restaurants below 2.5 have a slightly higher median than the 2.5-2.9 band, so the pattern is not perfectly monotone).
- Interpretation: well-rated restaurants collect more votes. Correlation does not show causation - popular restaurants may be rated by more (and different) people, and highly visible restaurants attract more voters.
- The relationship also holds within Delhi NCR alone (Spearman rho = 0.59), so it is not just a mix of cities.
