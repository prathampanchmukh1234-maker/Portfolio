# Level 1 - Task 2: City Analysis

- New Delhi has the most restaurants: 5,473 (57.3% of the dataset). Gurgaon (1,118) and Noida (1,080) follow, so the Delhi NCR region holds 83.2% of all records.
- Raw ranking: the highest average rating is Inner City (4.90) but it rests on only 2 rated restaurant(s), so this is not a reliable comparison.
- With at least 20 rated restaurants (n=71 cities), the highest average rating is London (4.54, 20 rated), followed by Orlando (4.47) and Tampa Bay (4.41).
- The overall average rating of rated restaurants is 3.44; New Delhi sits at 3.30.
- Across qualifying cities, restaurant count and average rating are negatively related (Spearman rho = -0.31, p = 0.01): the large Delhi NCR cities average about 3.1-3.3 while many small-sample cities average above 4.
- Sampling caveat: 136 of 141 cities have 21 or fewer restaurants (67 have exactly 20 and 46 have just one), so city counts outside Delhi NCR reflect how the dataset was assembled, not the true size of those cities' restaurant scenes.
