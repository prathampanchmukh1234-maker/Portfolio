# Level 1 - Task 3: Price Range Distribution

- Price range 1 is the most common (4,444 restaurants, 46.53%), followed by range 2 (3,113, 32.59%), range 3 (1,408, 14.74%) and range 4 (586, 6.14%).
- Ranges 1 and 2 together cover 79.1% of restaurants; the top price tier holds only 6.1%.
- The count falls at every step up the scale, so the market in this dataset is clearly skewed towards lower price tiers.
- For reference, the median cost for two in India (INR) rises from 300 (range 1) to 2,200 (range 4).
