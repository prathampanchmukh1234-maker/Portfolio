# %% [markdown]
# # Cognifyz Technologies - Data Analysis Internship
# ## Level 1: Basic Data Analysis
# Tasks: (1) Top Cuisines, (2) City Analysis, (3) Price Range Distribution, (4) Online Delivery.
#
# All numbers below are computed from the supplied dataset (`Dataset/original_dataset.csv`).
# Cleaning rules live in `common.py` and are summarised in the next section.

# %%
import sys
from pathlib import Path
try:
    HERE = Path(__file__).resolve().parent
except NameError:  # running inside a notebook
    HERE = Path.cwd()
sys.path.insert(0, str(HERE.parent))

import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
import common as cz
from common import BLUE, ORANGE, AQUA, INK2, MUTED, FADED, GRID

try:
    from IPython.display import display
except ImportError:
    display = print

pd.set_option("display.width", 140)
L1 = HERE
RES = {}  # key numbers saved for the reports

# %% [markdown]
# ## 0. Load and clean the data
# Decisions (full log is saved to `Reports/results/cleaning_log.json`):
# * Header BOM removed, text whitespace stripped. No duplicate rows / IDs were found.
# * `Aggregate rating == 0` is exactly the `Not rated` label, so **0 is treated as "no rating"** and excluded from rating averages.
# * 9 restaurants without `Cuisines` are kept but excluded from cuisine questions.
# * 54 city names damaged by an encoding fault in the source file were repaired (Brasilia, Sao Paulo, Istanbul).
# * Coordinates of exactly (0, 0) are placeholders and are ignored for maps (Level 2).

# %%
df, clog = cz.load_clean()
cz.dump_results(0, clog)
cz.RESULTS_DIR.joinpath("cleaning_log.json").write_text(__import__("json").dumps(clog, indent=2), encoding="utf-8")
print(f"Rows: {len(df):,}   Columns (raw): {clog['columns_raw']}")
print("Missing before cleaning:", clog["missing_before"])
print("Duplicate rows:", clog["duplicate_rows"], "| duplicate IDs:", clog["duplicate_restaurant_ids"])
print("Not-rated restaurants (rating 0):", clog["unrated_restaurants"])
display(df.dtypes.astype(str).rename("dtype").to_frame().T)

# %% [markdown]
# ---
# ## Task 1 - Top Cuisines
# A restaurant can list several cuisines, so the `Cuisines` text is split and each restaurant is counted once per cuisine it serves.
# Percentages use the 9,542 restaurants that list a cuisine as the base (shares therefore add up to more than 100%).

# %%
T1 = L1 / "Task_1_Top_Cuisines"
with_cuisine = df[df["Has_Cuisine"]]
n_base = len(with_cuisine)
exploded = with_cuisine[["Restaurant ID", "Cuisine_List"]].explode("Cuisine_List")
cuisine_counts = exploded.groupby("Cuisine_List")["Restaurant ID"].nunique().sort_values(ascending=False)
cuisine_tbl = pd.DataFrame({
    "Restaurants": cuisine_counts,
    "% of restaurants with cuisine info": (cuisine_counts / n_base * 100).round(2),
    "% of all restaurants (9,551)": (cuisine_counts / len(df) * 100).round(2),
})
cuisine_tbl.index.name = "Cuisine"
cz.save_table(cuisine_tbl, T1, "cuisine_counts_all")
top3 = cuisine_tbl.head(3)
display(top3)
print("Distinct cuisines:", len(cuisine_tbl))

# %%
top10 = cuisine_tbl.head(10).iloc[::-1]
fig, ax = cz.new_fig(10, 6)
colors = [FADED] * 7 + [BLUE] * 3          # highlight the top three
ax.barh(top10.index, top10["Restaurants"], color=colors, height=0.62)
cz.label_bars(ax, horizontal=True, values=[f"{r:,}  ({p:.1f}%)" for r, p in
                                            zip(top10["Restaurants"], top10["% of restaurants with cuisine info"])],
              fmt="{}")
ax.set_xlim(0, top10["Restaurants"].max() * 1.22)
ax.set_xlabel("Number of restaurants serving the cuisine"); cz.thousands(ax, "x")
ax.grid(axis="y", visible=False)
cz.titled(fig, "North Indian, Chinese and Fast Food lead the menu",
          f"Top 10 cuisines by number of restaurants (base: {n_base:,} restaurants with cuisine info; top 3 highlighted)")
cz.save_fig(fig, 1, "L1_T1_top_cuisines"); fig

# %%
obs1 = [
    f"The three most common cuisines are {top3.index[0]} ({top3.iloc[0,0]:,} restaurants, {top3.iloc[0,1]:.2f}%), "
    f"{top3.index[1]} ({top3.iloc[1,0]:,}, {top3.iloc[1,1]:.2f}%) and {top3.index[2]} ({top3.iloc[2,0]:,}, {top3.iloc[2,1]:.2f}%).",
    f"Percentages are measured against the {n_base:,} restaurants that list a cuisine; against all {len(df):,} rows they are "
    f"{top3.iloc[0,2]:.2f}%, {top3.iloc[1,2]:.2f}% and {top3.iloc[2,2]:.2f}%.",
    "",
]
obs1[2] = (f"{top3.index[0]} is listed by {top3.iloc[0,0]/top3.iloc[2,0]:.1f}x as many restaurants as {top3.index[2]}; "
           f"the dataset is concentrated on a few cuisines out of {len(cuisine_tbl)} distinct ones.")
obs1.append("Context: most records are from Delhi NCR (see Task 2), so the cuisine mix mainly reflects North India.")
for o in obs1: print("-", o)
cz.save_findings(T1, "Level 1 - Task 1: Top Cuisines", obs1)
RES["task1"] = {"top3": top3.reset_index().to_dict("records"), "n_base": n_base, "distinct": len(cuisine_tbl), "observations": obs1}

# %% [markdown]
# ---
# ## Task 2 - City Analysis
# * Restaurant count per city, and the average rating per city (**rated restaurants only**, since 0 means "not rated").
# * A city with one or two rated restaurants can top a raw ranking by chance, so the "highest average rating" is reported both
#   unfiltered and with a reliability threshold of at least 20 rated restaurants.

# %%
T2 = L1 / "Task_2_City_Analysis"
city = df.groupby("City").agg(Restaurants=("Restaurant ID", "count"), Rated=("Is_Rated", "sum"),
                              Avg_Rating=("Rating", "mean")).round(3)
city["Country"] = df.groupby("City")["Country"].first()
city = city.sort_values("Restaurants", ascending=False)
cz.save_table(city, T2, "city_summary_all")
top_city = city.index[0]
print(f"Cities: {len(city)} | most restaurants: {top_city} ({city.iloc[0]['Restaurants']:,} = {city.iloc[0]['Restaurants']/len(df)*100:.1f}% of all)")
display(city.head(10))

raw_best = city.dropna(subset=["Avg_Rating"]).sort_values(["Avg_Rating", "Rated"], ascending=False).head(5)
MIN_RATED = 20
reliable = city[city["Rated"] >= MIN_RATED].sort_values("Avg_Rating", ascending=False)
cz.save_table(reliable, T2, "city_avg_rating_min20_rated")
print("Raw top 5 (any sample size):"); display(raw_best)
print(f"Cities with >= {MIN_RATED} rated restaurants: {len(reliable)}"); display(reliable.head(10))

# %%
# Chart A - restaurant counts
top_n = city.head(10).iloc[::-1]
fig, ax = cz.new_fig(10, 6)
ax.barh(top_n.index, top_n["Restaurants"], color=[BLUE if c == top_city else FADED for c in top_n.index], height=0.62)
cz.label_bars(ax, horizontal=True); ax.set_xlim(0, top_n["Restaurants"].max() * 1.12)
ax.set_xlabel("Number of restaurants"); cz.thousands(ax, "x"); ax.grid(axis="y", visible=False)
cz.titled(fig, f"{top_city} dominates the dataset",
          f"Top 10 cities by number of restaurants ({len(city)} cities in total)")
cz.save_fig(fig, 1, "L1_T2_restaurants_by_city"); fig

# %%
# Chart B - average rating (reliable cities)
show = reliable.head(15).iloc[::-1]
overall = df["Rating"].mean()
fig, ax = cz.new_fig(10, 7)
ax.barh(show.index, show["Avg_Rating"], color=[BLUE if c == reliable.index[0] else FADED for c in show.index], height=0.62)
cz.label_bars(ax, fmt="{:.2f}", horizontal=True)
ax.axvline(overall, color=ORANGE, lw=1.6, ls="--")
ax.annotate(f"All rated restaurants: {overall:.2f}", (overall, len(show) - 0.35), xytext=(6, 0),
            textcoords="offset points", fontsize=9.5, color=INK2, va="center")
ax.set_xlim(0, 5.2); ax.set_xlabel("Average aggregate rating (rated restaurants only)"); ax.grid(axis="y", visible=False)
cz.titled(fig, f"{reliable.index[0]} has the highest average rating among reliably-sampled cities",
          f"Top 15 cities with at least {MIN_RATED} rated restaurants (n = {len(reliable)} cities qualify)")
cz.save_fig(fig, 1, "L1_T2_avg_rating_by_city"); fig

# %%
# Chart C - volume vs quality (bubble view of cities that qualify)
fig, ax = cz.new_fig(10, 6)
ax.scatter(reliable["Restaurants"], reliable["Avg_Rating"], s=70, color=BLUE, alpha=0.85, edgecolor=cz.SURFACE, lw=1.5)
for name, r in reliable.sort_values("Restaurants", ascending=False).head(6).iterrows():
    ax.annotate(name, (r["Restaurants"], r["Avg_Rating"]), xytext=(6, 5), textcoords="offset points", fontsize=9, color=INK2)
ax.set_xscale("log"); ax.set_xlabel("Number of restaurants (log scale)"); ax.set_ylabel("Average rating")
cz.titled(fig, "Cities with more restaurants have lower average ratings", f"Restaurant count vs average rating, cities with >= {MIN_RATED} rated restaurants")
cz.save_fig(fig, 1, "L1_T2_volume_vs_rating"); fig

# %%
rho, p_rho = stats.spearmanr(reliable["Restaurants"], reliable["Avg_Rating"])
obs2 = [
    f"{top_city} has the most restaurants: {city.iloc[0]['Restaurants']:,} ({city.iloc[0]['Restaurants']/len(df)*100:.1f}% of the dataset). "
    f"Gurgaon ({city.loc['Gurgaon','Restaurants']:,}) and Noida ({city.loc['Noida','Restaurants']:,}) follow, so the Delhi NCR region holds "
    f"{(city.loc[['New Delhi','Gurgaon','Noida','Faridabad','Ghaziabad'],'Restaurants'].sum())/len(df)*100:.1f}% of all records.",
    f"Raw ranking: the highest average rating is {raw_best.index[0]} ({raw_best.iloc[0]['Avg_Rating']:.2f}) but it rests on only "
    f"{int(raw_best.iloc[0]['Rated'])} rated restaurant(s), so this is not a reliable comparison.",
    f"With at least {MIN_RATED} rated restaurants (n={len(reliable)} cities), the highest average rating is {reliable.index[0]} "
    f"({reliable.iloc[0]['Avg_Rating']:.2f}, {int(reliable.iloc[0]['Rated'])} rated), followed by {reliable.index[1]} ({reliable.iloc[1]['Avg_Rating']:.2f}) "
    f"and {reliable.index[2]} ({reliable.iloc[2]['Avg_Rating']:.2f}).",
    f"The overall average rating of rated restaurants is {overall:.2f}; {top_city} sits at {city.loc[top_city,'Avg_Rating']:.2f}.",
    f"Across qualifying cities, restaurant count and average rating are negatively related (Spearman rho = {rho:.2f}, p = {p_rho:.2f}): "
    f"the large Delhi NCR cities average about 3.1-3.3 while many small-sample cities average above 4.",
    f"Sampling caveat: {int((city['Restaurants'] <= 21).sum())} of {len(city)} cities have 21 or fewer restaurants ({int((city['Restaurants'] == 20).sum())} have exactly 20 and {int((city['Restaurants'] == 1).sum())} have just one), so city counts outside Delhi NCR "
    f"reflect how the dataset was assembled, not the true size of those cities' restaurant scenes.",
]
for o in obs2: print("-", o)
cz.save_findings(T2, "Level 1 - Task 2: City Analysis", obs2)
RES["task2"] = {"top_city": top_city, "top_city_count": int(city.iloc[0]["Restaurants"]), "n_cities": len(city),
                "best_raw": raw_best.reset_index().head(3).to_dict("records"),
                "best_reliable": reliable.reset_index().head(5).to_dict("records"), "overall_avg": overall,
                "spearman": [rho, p_rho], "observations": obs2}

# %% [markdown]
# ---
# ## Task 3 - Price Range Distribution
# `Price range` is a 1-4 scale (1 = lowest, 4 = highest). It is used instead of `Average Cost for two` because the cost
# column is expressed in 12 different currencies and is not comparable across countries.

# %%
T3 = L1 / "Task_3_Price_Range_Distribution"
pr = df["Price range"].value_counts().sort_index()
pr_tbl = pd.DataFrame({"Restaurants": pr, "Percentage (%)": (pr / len(df) * 100).round(2)})
pr_tbl["Cumulative (%)"] = pr_tbl["Percentage (%)"].cumsum().round(2)
pr_tbl.index = [PRICE for PRICE in pr_tbl.index]; pr_tbl.index.name = "Price range"
pr_tbl.loc["Total"] = [pr.sum(), 100.0, np.nan]
cz.save_table(pr_tbl, T3, "price_range_distribution")
display(pr_tbl.style.format({"Restaurants": "{:,.0f}", "Percentage (%)": "{:.2f}", "Cumulative (%)": "{:.2f}"}, na_rep=""))

# India-only median cost to show what the levels mean (INR only, so values are comparable)
india_cost = df[df["Country"] == "India"].groupby("Price range")["Average Cost for two"].median()
display(india_cost.rename("India: median cost for two (INR)").to_frame())

# %%
fig, ax = cz.new_fig(9, 6)
vals = pr_tbl.iloc[:4]
bars = ax.bar([cz.PRICE_LABELS[i] for i in vals.index], vals["Restaurants"], color=BLUE, width=0.55)
cz.label_bars(ax, values=[f"{r:,.0f}\n({p:.1f}%)" for r, p in zip(vals["Restaurants"], vals["Percentage (%)"])], fmt="{}")
ax.set_ylim(0, vals["Restaurants"].max() * 1.18); cz.thousands(ax)
ax.set_xlabel("Price range"); ax.set_ylabel("Number of restaurants"); ax.grid(axis="x", visible=False)
cz.titled(fig, "Budget-friendly restaurants make up almost half of the dataset",
          f"Distribution of price ranges across {len(df):,} restaurants")
cz.save_fig(fig, 1, "L1_T3_price_range_distribution"); fig

# %%
p1, p2, p3, p4 = (pr_tbl.loc[i, "Percentage (%)"] for i in (1, 2, 3, 4))
obs3 = [
    f"Price range 1 is the most common ({pr[1]:,} restaurants, {p1:.2f}%), followed by range 2 ({pr[2]:,}, {p2:.2f}%), range 3 ({pr[3]:,}, {p3:.2f}%) and range 4 ({pr[4]:,}, {p4:.2f}%).",
    f"Ranges 1 and 2 together cover {p1 + p2:.1f}% of restaurants; the top price tier holds only {p4:.1f}%.",
    f"The count falls at every step up the scale, so the market in this dataset is clearly skewed towards lower price tiers.",
    f"For reference, the median cost for two in India (INR) rises from {india_cost[1]:,.0f} (range 1) to {india_cost[4]:,.0f} (range 4).",
]
for o in obs3: print("-", o)
cz.save_findings(T3, "Level 1 - Task 3: Price Range Distribution", obs3)
RES["task3"] = {"table": pr_tbl.iloc[:4].reset_index().to_dict("records"), "india_median_cost": india_cost.to_dict(), "observations": obs3}

# %% [markdown]
# ---
# ## Task 4 - Online Delivery
# Percentage of restaurants with online delivery, and the average rating (rated restaurants only) with vs without it.
# Online delivery is only recorded in **India and the UAE** (0% elsewhere), so a second comparison restricted to those two
# countries is shown to avoid mixing in markets where the feature does not exist in the data.

# %%
T4 = L1 / "Task_4_Online_Delivery"
n_del = int(df["Has_Delivery"].sum()); pct_del = n_del / len(df) * 100
by_country = (df.groupby("Country")["Has_Delivery"].agg(["sum", "count", "mean"])
              .rename(columns={"sum": "With delivery", "count": "Restaurants", "mean": "Share"}).sort_values("Share", ascending=False))
by_country["Share"] = (by_country["Share"] * 100).round(2)
cz.save_table(by_country, T4, "delivery_by_country")
display(by_country.head(4))

def delivery_summary(frame):
    g = frame.groupby("Has_Delivery").agg(Restaurants=("Restaurant ID", "count"), Rated=("Is_Rated", "sum"),
                                          Avg_Rating=("Rating", "mean"), Median_Rating=("Rating", "median"))
    g.index = g.index.map({True: "With online delivery", False: "Without online delivery"})
    return g.round(3)

overall_cmp = delivery_summary(df)
subset = df[df["Country"].isin(["India", "UAE"])]
subset_cmp = delivery_summary(subset)
india_cmp = delivery_summary(df[df["Country"] == "India"])
cz.save_table(overall_cmp, T4, "rating_comparison_all")
cz.save_table(subset_cmp, T4, "rating_comparison_india_uae")
cz.save_table(india_cmp, T4, "rating_comparison_india")
print("All restaurants:"); display(overall_cmp)
print("India + UAE only:"); display(subset_cmp)
print("India only:"); display(india_cmp)

def mwu(frame):
    a = frame.loc[frame["Has_Delivery"] & frame["Is_Rated"], "Rating"]; b = frame.loc[~frame["Has_Delivery"] & frame["Is_Rated"], "Rating"]
    u = stats.mannwhitneyu(a, b, alternative="two-sided")
    return a.mean() - b.mean(), u.pvalue
diff_all, p_all = mwu(df); diff_sub, p_sub = mwu(subset)
share_rated = df.groupby("Has_Delivery")["Is_Rated"].mean() * 100
print(f"Mean difference (all): {diff_all:+.3f}, Mann-Whitney p={p_all:.2e} | India+UAE: {diff_sub:+.3f}, p={p_sub:.2e}")
print("Share of restaurants that are rated:", share_rated.round(1).to_dict())

# %%
fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 6), gridspec_kw={"width_ratios": [1, 1.25]})
a1.bar(["With online\ndelivery", "Without online\ndelivery"], [pct_del, 100 - pct_del], color=[BLUE, FADED], width=0.55)
cz.label_bars(a1, fmt="{:.1f}%"); a1.set_ylim(0, 100); a1.set_ylabel("Share of restaurants (%)")
a1.set_title("Availability", loc="left", fontsize=11, color=INK2); a1.grid(axis="x", visible=False)
labels = ["All\nrestaurants", "India + UAE\nonly"]
x = np.arange(2); w = 0.34
wd = [overall_cmp.loc["With online delivery", "Avg_Rating"], subset_cmp.loc["With online delivery", "Avg_Rating"]]
wo = [overall_cmp.loc["Without online delivery", "Avg_Rating"], subset_cmp.loc["Without online delivery", "Avg_Rating"]]
a2.bar(x - w / 2, wd, w, color=BLUE, label="With online delivery"); a2.bar(x + w / 2, wo, w, color=ORANGE, label="Without online delivery")
cz.label_bars(a2, fmt="{:.2f}"); a2.set_xticks(x, labels); a2.set_ylim(0, 5); a2.set_ylabel("Average rating (rated restaurants)")
a2.set_title("Average rating", loc="left", fontsize=11, color=INK2); a2.legend(loc="upper right", ncol=1); a2.grid(axis="x", visible=False)
cz.titled(fig, "Online delivery makes little practical difference to average rating",
          "Online delivery availability and average ratings (delivery is only recorded for India and the UAE)", top=0.80)
cz.save_fig(fig, 1, "L1_T4_online_delivery"); fig

# %%
fig, ax = cz.new_fig(9, 6)
data = [subset.loc[subset["Has_Delivery"] & subset["Is_Rated"], "Rating"], subset.loc[~subset["Has_Delivery"] & subset["Is_Rated"], "Rating"]]
bp = ax.boxplot(data, tick_labels=["With online delivery", "Without online delivery"], patch_artist=True, widths=0.5,
                medianprops={"color": INK2, "lw": 2}, flierprops={"markersize": 3, "markeredgecolor": MUTED})
for patch, c in zip(bp["boxes"], [BLUE, ORANGE]): patch.set(facecolor=c, alpha=0.75, edgecolor=cz.SURFACE)
ax.set_ylabel("Aggregate rating"); ax.grid(axis="x", visible=False)
cz.titled(fig, "Rating spread is similar with and without online delivery", "Rated restaurants in India and the UAE")
cz.save_fig(fig, 1, "L1_T4_rating_boxplot"); fig

# %%
obs4 = [
    f"{n_del:,} of {len(df):,} restaurants offer online delivery: {pct_del:.2f}%; {100 - pct_del:.2f}% do not.",
    f"Delivery is only recorded in India ({by_country.loc['India','Share']:.1f}% of its restaurants) and the UAE ({by_country.loc['UAE','Share']:.1f}%); it is 0% in the other {len(by_country) - 2} countries.",
    f"Average rating (rated restaurants): {overall_cmp.loc['With online delivery','Avg_Rating']:.2f} with delivery vs {overall_cmp.loc['Without online delivery','Avg_Rating']:.2f} without "
    f"(difference {diff_all:+.2f}, Mann-Whitney p = {p_all:.1e}).",
    f"Restricting to India + UAE, where delivery exists: {subset_cmp.loc['With online delivery','Avg_Rating']:.2f} vs {subset_cmp.loc['Without online delivery','Avg_Rating']:.2f} "
    f"(difference {diff_sub:+.2f}, p = {p_sub:.1e}).",
    f"Unrated restaurants are more common without delivery: {100 - share_rated[False]:.1f}% vs {100 - share_rated[True]:.1f}% with delivery, which should be remembered when comparing averages.",
    f"The all-restaurant gap ({diff_all:+.2f}) changes sign inside India + UAE ({diff_sub:+.2f}): the overall figure is pulled down because the 13 countries with no delivery data "
    "(e.g. UK, US, Australia) contain many highly rated restaurants. Within the markets where delivery exists, the difference is only about 0.03 rating points - statistically detectable "
    "with thousands of restaurants but practically negligible.",
    "This is an association, not proof that offering delivery changes ratings.",
]
for o in obs4: print("-", o)
cz.save_findings(T4, "Level 1 - Task 4: Online Delivery", obs4)
RES["task4"] = {"pct_delivery": pct_del, "n_delivery": n_del, "overall": overall_cmp.reset_index().to_dict("records"),
                "subset": subset_cmp.reset_index().to_dict("records"), "diff_all": diff_all, "p_all": p_all,
                "diff_subset": diff_sub, "p_subset": p_sub, "by_country": by_country.reset_index().head(3).to_dict("records"),
                "observations": obs4}

# %% [markdown]
# ---
# ## Level 1 summary and export

# %%
cz.dump_results(1, RES)
print("Level 1 complete. Charts:", sorted(p.name for p in (cz.VIZ_DIR / "Level_1").glob("*.png")))
