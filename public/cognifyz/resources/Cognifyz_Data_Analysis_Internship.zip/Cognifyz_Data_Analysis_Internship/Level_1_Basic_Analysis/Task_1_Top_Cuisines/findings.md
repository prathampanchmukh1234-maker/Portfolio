# Level 1 - Task 1: Top Cuisines

- The three most common cuisines are North Indian (3,960 restaurants, 41.50%), Chinese (2,733, 28.64%) and Fast Food (1,986, 20.81%).
- Percentages are measured against the 9,542 restaurants that list a cuisine; against all 9,551 rows they are 41.46%, 28.61% and 20.79%.
- North Indian is listed by 2.0x as many restaurants as Fast Food; the dataset is concentrated on a few cuisines out of 145 distinct ones.
- Context: most records are from Delhi NCR (see Task 2), so the cuisine mix mainly reflects North India.
