# Level 1 - Task 4: Online Delivery

- 2,451 of 9,551 restaurants offer online delivery: 25.66%; 74.34% do not.
- Delivery is only recorded in India (28.0% of its restaurants) and the UAE (46.7%); it is 0% in the other 13 countries.
- Average rating (rated restaurants): 3.38 with delivery vs 3.47 without (difference -0.09, Mann-Whitney p = 8.7e-04).
- Restricting to India + UAE, where delivery exists: 3.38 vs 3.35 (difference +0.03, p = 2.6e-07).
- Unrated restaurants are more common without delivery: 28.9% vs 3.9% with delivery, which should be remembered when comparing averages.
- The all-restaurant gap (-0.09) changes sign inside India + UAE (+0.03): the overall figure is pulled down because the 13 countries with no delivery data (e.g. UK, US, Australia) contain many highly rated restaurants. Within the markets where delivery exists, the difference is only about 0.03 rating points - statistically detectable with thousands of restaurants but practically negligible.
- This is an association, not proof that offering delivery changes ratings.
