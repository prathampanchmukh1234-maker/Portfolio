"""
qa_check.py - independent verification of the analysis results and deliverables.

Key numbers are recomputed here with a DIFFERENT code path (plain Python / NumPy on the raw CSV)
and compared with the values saved by the Level scripts. A task is marked 'Completed' only if its
numbers match and its output files exist. Level 3 Task 1 is marked 'Blocked - Missing Data' only after
re-checking that the dataset has no review text.

Run:  python qa_check.py        (writes Reports/results/completion_matrix.json and prints a report)
"""
import csv
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
RES = ROOT / "Reports" / "results"
R = {l: json.loads((RES / f"level_{l}_results.json").read_text(encoding="utf-8")) for l in (1, 2, 3)}

with open(ROOT / "Dataset" / "original_dataset.csv", encoding="utf-8-sig", newline="") as f:
    rows = list(csv.DictReader(f))
N = len(rows)
checks = []  # (task, description, ok)


def check(task, desc, ok):
    checks.append((task, desc, bool(ok)))


def close(a, b, tol=1e-6):
    return math.isclose(a, b, rel_tol=tol, abs_tol=tol)


# ---- L1T1 top cuisines
cc = Counter()
with_c = 0
for r in rows:
    if r["Cuisines"].strip():
        with_c += 1
        for c in {x.strip() for x in r["Cuisines"].split(",")}: cc[c] += 1
top = cc.most_common(3)
t1 = R[1]["task1"]["top3"]
check("L1T1", "top-3 cuisine names and counts", [(t["Cuisine"], t["Restaurants"]) for t in t1] == top)
check("L1T1", "percentage base 9,542", with_c == R[1]["task1"]["n_base"] == 9542)
check("L1T1", "top-1 percentage", close(round(top[0][1] / with_c * 100, 2), t1[0]["% of restaurants with cuisine info"]))

# ---- L1T2 city
cities = Counter(r["City"] for r in rows)
check("L1T2", "most restaurants = New Delhi (count)", cities.most_common(1)[0][1] == R[1]["task2"]["top_city_count"] and R[1]["task2"]["top_city"] == "New Delhi")
by_city = defaultdict(list)
for r in rows:
    if float(r["Aggregate rating"]) > 0: by_city[r["City"]].append(float(r["Aggregate rating"]))
reliable = {c: np.mean(v) for c, v in by_city.items() if len(v) >= 20}
best = max(reliable, key=reliable.get)
check("L1T2", "highest avg rating (>=20 rated) city", best == R[1]["task2"]["best_reliable"][0]["City"])
check("L1T2", "highest avg rating value", close(round(reliable[best], 3), R[1]["task2"]["best_reliable"][0]["Avg_Rating"], 1e-3))

# ---- L1T3 price range
pr = Counter(int(r["Price range"]) for r in rows)
tab = {t["Price range"]: t for t in R[1]["task3"]["table"]}
check("L1T3", "price range counts and percentages", all(tab[k]["Restaurants"] == pr[k] and close(round(pr[k] / N * 100, 2), tab[k]["Percentage (%)"]) for k in (1, 2, 3, 4)))
check("L1T3", "percentages sum to 100", close(sum(t["Percentage (%)"] for t in tab.values()), 100.0, 1e-3))

# ---- L1T4 delivery
yes = sum(r["Has Online delivery"] == "Yes" for r in rows)
check("L1T4", "delivery count and percentage", yes == R[1]["task4"]["n_delivery"] and close(yes / N * 100, R[1]["task4"]["pct_delivery"]))
w = [float(r["Aggregate rating"]) for r in rows if r["Has Online delivery"] == "Yes" and float(r["Aggregate rating"]) > 0]
wo = [float(r["Aggregate rating"]) for r in rows if r["Has Online delivery"] == "No" and float(r["Aggregate rating"]) > 0]
check("L1T4", "mean rating with delivery", close(round(np.mean(w), 3), [x for x in R[1]["task4"]["overall"] if x["Has_Delivery"].startswith("With online")][0]["Avg_Rating"], 1e-3))
check("L1T4", "mean rating without delivery", close(round(np.mean(wo), 3), [x for x in R[1]["task4"]["overall"] if x["Has_Delivery"].startswith("Without")][0]["Avg_Rating"], 1e-3))

# ---- L2T1 ratings and votes
votes = np.array([int(r["Votes"]) for r in rows])
check("L2T1", "average votes (all restaurants)", close(votes.mean(), R[2]["task1"]["mean_votes_all"]))
rated = np.array([float(r["Aggregate rating"]) for r in rows if float(r["Aggregate rating"]) > 0])
edges = np.arange(1.5, 5.01, 0.5)
hist = [int(((rated >= a) & (rated < b if b < 5 else rated <= 5)).sum()) for a, b in zip(edges[:-1], edges[1:])]
mx = int(np.argmax(hist))
check("L2T1", "most common 0.5-wide rating range", R[2]["task1"]["top_band"].startswith(f"{edges[mx]:.1f}"))
check("L2T1", "rated count 7,403", len(rated) == 7403 == sum(hist))

# ---- L2T2 cuisine combos
combos = Counter(", ".join(sorted({x.strip() for x in r["Cuisines"].split(",") if x.strip()})) for r in rows if r["Cuisines"].strip())
check("L2T2", "number of distinct combinations", len(combos) == R[2]["task2"]["n_combos"])
check("L2T2", "most common combination", combos.most_common(1)[0][0] == R[2]["task2"]["top"][0]["Cuisine_Combo"] and combos.most_common(1)[0][1] == R[2]["task2"]["top"][0]["Restaurants"])

# ---- L2T3 geographic
valid = [r for r in rows if not (float(r["Longitude"]) == 0 and float(r["Latitude"]) == 0)]
india_bad = [r for r in valid if r["Country Code"] == "1" and not (6 <= float(r["Latitude"]) <= 37 and 68 <= float(r["Longitude"]) <= 98)]
check("L2T3", "mappable restaurant count", len(valid) - len(india_bad) == R[2]["task3"]["mappable"])
check("L2T3", "interactive Folium map exists", (ROOT / "Visualizations/Level_2/L2_T3_interactive_map.html").stat().st_size > 100_000)

# ---- L2T4 chains
names = Counter(r["Restaurant Name"].strip().casefold() for r in rows)
chains = {k: v for k, v in names.items() if v >= 2}
check("L2T4", "number of chains (>=2 outlets)", len(chains) == R[2]["task4"]["n_chains"])
check("L2T4", "restaurants in chains", sum(chains.values()) == R[2]["task4"]["chain_outlets"])

# ---- L3T1 review text availability (re-check)
review_cols = [c for c in rows[0] if any(k in c.lower() for k in ("review", "comment", "feedback", "opinion"))]
avg_words = {c: np.mean([len(r[c].split()) for r in rows]) for c in rows[0] if not c.replace("\ufeff", "") in ("Restaurant ID",) and any(ch.isalpha() for r in rows[:50] for ch in r[c])}
longest_avg = max(avg_words.values())  # a column of real reviews would average well above 10 words
no_reviews = (not review_cols) and longest_avg < 10 and not any(a["Looks like review text?"] == "Yes" for a in R[3]["task1"]["audit"]) and R[3]["task1"]["status"].startswith("Blocked")
check("L3T1", "no review-text column exists (task correctly blocked)", no_reviews)

# ---- L3T2 votes correlation
rr = [(int(r["Votes"]), float(r["Aggregate rating"])) for r in rows if float(r["Aggregate rating"]) > 0]
pearson = np.corrcoef([a for a, _ in rr], [b for _, b in rr])[0, 1]
check("L3T2", "Pearson r (votes vs rating, rated)", close(round(pearson, 3), R[3]["task2"]["corr"][0]["Pearson r"], 1e-3))
top_row = max(rows, key=lambda r: int(r["Votes"]))
check("L3T2", "highest-voted restaurant", int(top_row["Votes"]) == R[3]["task2"]["highest"][0]["Votes"] and top_row["Restaurant Name"] == R[3]["task2"]["highest"][0]["Restaurant Name"])
check("L3T2", "restaurants with zero votes", sum(int(r["Votes"]) == 0 for r in rows) == R[3]["task2"]["n_zero"])

# ---- L3T3 price vs service
summ = {s["Price range"]: s for s in R[3]["task3"]["summary"]}
ok_d = ok_b = True
for k in (1, 2, 3, 4):
    grp = [r for r in rows if int(r["Price range"]) == k]
    d = sum(r["Has Online delivery"] == "Yes" for r in grp) / len(grp) * 100
    b = sum(r["Has Table booking"] == "Yes" for r in grp) / len(grp) * 100
    ok_d &= close(round(d, 2), summ[k]["All restaurants - Online delivery"], 1e-3)
    ok_b &= close(round(b, 2), summ[k]["All restaurants - Table booking"], 1e-3)
check("L3T3", "delivery % by price range", ok_d)
check("L3T3", "table booking % by price range", ok_b)

# ---- artefact existence per task
ARTE = {
    "L1T1": ("Level_1_Basic_Analysis/Task_1_Top_Cuisines", ["L1_T1_top_cuisines.png"]),
    "L1T2": ("Level_1_Basic_Analysis/Task_2_City_Analysis", ["L1_T2_restaurants_by_city.png", "L1_T2_avg_rating_by_city.png"]),
    "L1T3": ("Level_1_Basic_Analysis/Task_3_Price_Range_Distribution", ["L1_T3_price_range_distribution.png"]),
    "L1T4": ("Level_1_Basic_Analysis/Task_4_Online_Delivery", ["L1_T4_online_delivery.png"]),
    "L2T1": ("Level_2_Intermediate_Analysis/Task_1_Restaurant_Ratings", ["L2_T1_rating_distribution.png", "L2_T1_votes_distribution.png"]),
    "L2T2": ("Level_2_Intermediate_Analysis/Task_2_Cuisine_Combination", ["L2_T2_top_combinations.png", "L2_T2_combination_ratings.png"]),
    "L2T3": ("Level_2_Intermediate_Analysis/Task_3_Geographic_Analysis", ["L2_T3_ncr_density_hexbin.png", "L2_T3_interactive_map.html"]),
    "L2T4": ("Level_2_Intermediate_Analysis/Task_4_Restaurant_Chains", ["L2_T4_chain_ratings.png", "L2_T4_rating_vs_popularity.png"]),
    "L3T1": ("Level_3_Advanced_Analysis/Task_1_Restaurant_Reviews", []),
    "L3T2": ("Level_3_Advanced_Analysis/Task_2_Votes_Analysis", ["L3_T2_votes_vs_rating_scatter.png"]),
    "L3T3": ("Level_3_Advanced_Analysis/Task_3_Price_Delivery_Table_Booking", ["L3_T3_service_by_price_range.png"]),
}
for t, (folder, charts) in ARTE.items():
    lvl = t[1]
    ok = (ROOT / folder / "findings.md").exists() and any((ROOT / folder).glob("*.csv"))
    ok &= all((ROOT / "Visualizations" / f"Level_{lvl}" / c).exists() for c in charts)
    check(t, "findings, tables and charts exist", ok)

# ---- project-level deliverables
DELIV = ["README.md", "Dataset/original_dataset.csv", "Dataset/cleaned_dataset.csv", "Level_1_Basic_Analysis/Level_1_Analysis.ipynb", "Level_1_Basic_Analysis/Level_1_Analysis.py",
         "Level_2_Intermediate_Analysis/Level_2_Analysis.ipynb", "Level_2_Intermediate_Analysis/Level_2_Analysis.py", "Level_3_Advanced_Analysis/Level_3_Analysis.ipynb",
         "Level_3_Advanced_Analysis/Level_3_Analysis.py", "Reports/Level_1_Report.pdf", "Reports/Level_2_Report.pdf", "Reports/Level_3_Report.pdf", "Reports/Final_Internship_Report.pdf",
         "Presentation/Internship_Presentation.pptx", "Submission/LinkedIn_Post.md", "Submission/Video_Demonstration_Script.md", "Submission/Submission_Checklist.md"]
missing = [d for d in DELIV if not (ROOT / d).exists()]
tasks_meta = {
    "L1T1": ("Level 1", "Top Cuisines"), "L1T2": ("Level 1", "City Analysis"), "L1T3": ("Level 1", "Price Range Distribution"), "L1T4": ("Level 1", "Online Delivery"),
    "L2T1": ("Level 2", "Restaurant Ratings"), "L2T2": ("Level 2", "Cuisine Combination"), "L2T3": ("Level 2", "Geographic Analysis"), "L2T4": ("Level 2", "Restaurant Chains"),
    "L3T1": ("Level 3", "Restaurant Reviews"), "L3T2": ("Level 3", "Votes Analysis"), "L3T3": ("Level 3", "Price Range vs Delivery & Booking")}
matrix = []
for t, (lvl, name) in tasks_meta.items():
    mine = [c for c in checks if c[0] == t]
    ok = all(c[2] for c in mine)
    if t == "L3T1":
        status = "Blocked - Missing Data" if ok else "Partially Completed"
        ev = "Dataset has no review text; audit + reusable template provided" if ok else "audit failed"
    else:
        status = "Completed" if ok else "Partially Completed"
        ev = f"{sum(c[2] for c in mine)}/{len(mine)} independent checks passed"
    matrix.append({"Level": lvl, "Task": name, "Status": status, "Evidence": ev})
(RES / "completion_matrix.json").write_text(json.dumps(matrix, indent=2), encoding="utf-8")

print(f"{'TASK':6} {'RESULT':6} CHECK")
for t, d, ok in checks: print(f"{t:6} {'PASS' if ok else 'FAIL':6} {d}")
print("\nCompletion matrix:")
for m in matrix: print(f"  {m['Level']:8} {m['Task']:36} {m['Status']:24} {m['Evidence']}")
print("\nMissing deliverables:", missing or "none")
print("ALL CHECKS PASSED" if all(c[2] for c in checks) else "SOME CHECKS FAILED")
