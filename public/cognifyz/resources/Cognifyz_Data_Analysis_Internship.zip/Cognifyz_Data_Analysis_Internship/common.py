"""
common.py - shared helpers for the Cognifyz Data Analysis Internship project.

Responsibilities
----------------
* Load and clean the restaurant dataset (single source of truth for all levels).
* Provide one consistent chart style and export helpers (PNG, 200 dpi).
* Save result tables / key numbers so reports are generated from real results.

Every Level_N_Analysis.py script and notebook imports this module, which keeps
cleaning decisions and chart styling identical across all three levels.
"""
from pathlib import Path
import json

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")  # file-based rendering; notebooks still show inline via display()
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "Dataset" / "original_dataset.csv"
CLEAN_PATH = ROOT / "Dataset" / "cleaned_dataset.csv"
VIZ_DIR = ROOT / "Visualizations"
RESULTS_DIR = ROOT / "Reports" / "results"
for _d in (VIZ_DIR, RESULTS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------
# Palette (validated categorical slots 1-3 + one-hue sequential + neutrals)
# --------------------------------------------------------------------------
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, INK2, MUTED = "#0b0b0b", "#52514e", "#8a8985"
GRID, SURFACE, FADED = "#e6e5e1", "#fcfcfb", "#c9d6e8"
SEQ_BLUES = ["#dbe7f6", "#a9c6ec", "#6a9fe0", "#2a78d6", "#1a4f93"]
SOURCE_NOTE = "Source: Cognifyz restaurant dataset (Dataset.csv)"

# Country codes -> names. The dataset has no country lookup file, so this mapping
# is the widely used code table for this dataset; each entry was cross-checked
# against the cities and currencies present in the data (see Level 1 notebook).
COUNTRY_NAMES = {
    1: "India", 14: "Australia", 30: "Brazil", 37: "Canada", 94: "Indonesia",
    148: "New Zealand", 162: "Philippines", 166: "Qatar", 184: "Singapore",
    189: "South Africa", 191: "Sri Lanka", 208: "Turkey", 214: "UAE",
    215: "United Kingdom", 216: "United States",
}

# City names damaged by an encoding problem in the source file (the original bytes
# are already replaced by U+FFFD, so they cannot be recovered programmatically).
CITY_REPAIRS = {"Bras�_lia": "Brasilia", "S��o Paulo": "Sao Paulo",
                "��stanbul": "Istanbul"}

PRICE_LABELS = {1: "1 (lowest)", 2: "2", 3: "3", 4: "4 (highest)"}


# --------------------------------------------------------------------------
# Cleaning
# --------------------------------------------------------------------------
def load_raw() -> pd.DataFrame:
    """Read the original CSV untouched (BOM-safe)."""
    return pd.read_csv(DATA_PATH, encoding="utf-8-sig")


def load_clean(save: bool = True):
    """Return (clean_df, cleaning_log). All decisions are recorded in the log."""
    raw = load_raw()
    df = raw.copy()
    log = {"rows_raw": int(len(raw)), "columns_raw": int(raw.shape[1])}

    # 1. Tidy headers and text whitespace
    df.columns = [c.strip() for c in df.columns]
    for col in df.select_dtypes(include=["object", "string"]).columns:
        df[col] = df[col].astype("string").str.strip()

    # 2. Duplicates
    log["duplicate_rows"] = int(df.duplicated().sum())
    log["duplicate_restaurant_ids"] = int(df["Restaurant ID"].duplicated().sum())

    # 3. Missing values (before any treatment)
    log["missing_before"] = {k: int(v) for k, v in df.isna().sum().items() if v > 0}

    # 4. Repair city names broken by encoding (documented, 54 rows)
    broken = df["City"].isin(CITY_REPAIRS)
    log["city_names_repaired_rows"] = int(broken.sum())
    df["City"] = df["City"].replace(CITY_REPAIRS)
    log["cells_with_unrecoverable_encoding_chars"] = {
        c: int(df[c].astype("string").str.contains("�", na=False).sum())
        for c in ["Restaurant Name", "Locality", "Locality Verbose", "Address", "Cuisines", "Currency"]
    }

    # 5. Binary flags (Yes/No -> bool)
    df["Has_Delivery"] = df["Has Online delivery"].eq("Yes")
    df["Has_Booking"] = df["Has Table booking"].eq("Yes")

    # 6. Ratings: 0.0 means "Not rated" (verified: Aggregate rating == 0 <=> Rating text == 'Not rated').
    #    Zero is NOT a real score, so it is excluded from every rating average (kept for vote analysis).
    log["rating_zero_equals_not_rated"] = bool((df["Aggregate rating"].eq(0)).equals(df["Rating text"].eq("Not rated")))
    df["Is_Rated"] = df["Aggregate rating"] > 0
    df["Rating"] = df["Aggregate rating"].where(df["Is_Rated"])  # NaN when not rated
    log["unrated_restaurants"] = int((~df["Is_Rated"]).sum())

    # 7. Cuisines: split into lists; 9 restaurants have no cuisine -> kept, flagged, excluded from cuisine tasks
    df["Has_Cuisine"] = df["Cuisines"].notna()
    df["Cuisine_List"] = df["Cuisines"].fillna("").map(
        lambda s: sorted({c.strip() for c in s.split(",") if c.strip()}))
    df["Cuisine_Count"] = df["Cuisine_List"].map(len)
    df["Cuisine_Combo"] = df["Cuisine_List"].map(", ".join)
    log["missing_cuisines_kept_flagged"] = int((~df["Has_Cuisine"]).sum())

    # 8. Coordinates: (0, 0) is a placeholder, not a real location; also bounds-check
    zero = df["Longitude"].eq(0) & df["Latitude"].eq(0)
    out_of_range = ~df["Longitude"].between(-180, 180) | ~df["Latitude"].between(-90, 90)
    df["Valid_Coords"] = ~(zero | out_of_range)
    log["placeholder_zero_coordinates"] = int(zero.sum())
    log["invalid_coordinates_excluded_from_maps"] = int((~df["Valid_Coords"]).sum())

    # 9. Country names; Price range as ordered category
    df["Country"] = df["Country Code"].map(COUNTRY_NAMES)
    log["unmapped_country_codes"] = int(df["Country"].isna().sum())
    df["Chain_Key"] = df["Restaurant Name"].str.casefold()  # used for chain detection

    # 10. Currency note: Average Cost for two is in local currencies -> not comparable across countries
    log["currencies"] = int(df["Currency"].nunique())
    log["rows_clean"] = int(len(df))

    if save:
        df.drop(columns=["Cuisine_List"]).to_csv(CLEAN_PATH, index=False, encoding="utf-8")
    return df, log


# --------------------------------------------------------------------------
# Chart style and helpers
# --------------------------------------------------------------------------
def apply_style():
    plt.rcParams.update({
        "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
        "font.family": "DejaVu Sans", "font.size": 10.5, "text.color": INK,
        "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.spines.left": False, "axes.spines.bottom": True, "axes.edgecolor": GRID,
        "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8,
        "axes.axisbelow": True, "legend.frameon": False, "figure.dpi": 100,
    })


apply_style()


def new_fig(w=10, h=6, **kw):
    fig, ax = plt.subplots(figsize=(w, h), **kw)
    return fig, ax


def titled(fig, title, subtitle=None, note=SOURCE_NOTE, top=0.86):
    """Left-aligned title + subtitle + footnote; leaves room so nothing overlaps."""
    fig.subplots_adjust(top=top, bottom=0.12)
    fig.text(0.04, 0.965, title, fontsize=15, fontweight="bold", ha="left", va="top", color=INK)
    if subtitle:
        fig.text(0.04, 0.915, subtitle, fontsize=10.5, ha="left", va="top", color=INK2)
    if note:
        fig.text(0.04, 0.02, note, fontsize=8.5, ha="left", va="bottom", color=MUTED)


def save_fig(fig, level: int, name: str):
    out = VIZ_DIR / f"Level_{level}"
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{name}.png"
    fig.savefig(path, dpi=200, bbox_inches="tight", pad_inches=0.35)
    plt.close(fig)
    return path


def label_bars(ax, fmt="{:,.0f}", horizontal=False, pad=4, size=9.5, values=None):
    """Direct value labels on bars (ink colour, never the series colour)."""
    for i, p in enumerate(ax.patches):
        v = values[i] if values is not None else (p.get_width() if horizontal else p.get_height())
        if horizontal:
            ax.annotate(fmt.format(v), (p.get_width(), p.get_y() + p.get_height() / 2),
                        xytext=(pad, 0), textcoords="offset points", va="center", fontsize=size, color=INK)
        else:
            ax.annotate(fmt.format(v), (p.get_x() + p.get_width() / 2, p.get_height()),
                        xytext=(0, pad), textcoords="offset points", ha="center", fontsize=size, color=INK)


def thousands(ax, axis="y"):
    f = FuncFormatter(lambda v, _: f"{v:,.0f}")
    (ax.yaxis if axis == "y" else ax.xaxis).set_major_formatter(f)


# --------------------------------------------------------------------------
# Results persistence (feeds the PDF reports and the presentation)
# --------------------------------------------------------------------------
def save_table(df: pd.DataFrame, folder: Path, name: str, index=True):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    df.to_csv(folder / f"{name}.csv", index=index, encoding="utf-8")


def save_findings(folder: Path, title: str, observations):
    """Write the observations printed by the analysis into the task folder."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    body = "\n".join(f"- {o}" for o in observations)
    (folder / "findings.md").write_text(f"# {title}\n\n{body}\n", encoding="utf-8")


def dump_results(level: int, payload: dict):
    def conv(o):
        if isinstance(o, (np.integer,)):
            return int(o)
        if isinstance(o, (np.floating,)):
            return float(o)
        if isinstance(o, (np.bool_,)):
            return bool(o)
        if isinstance(o, (pd.DataFrame,)):
            return o.to_dict(orient="records")
        raise TypeError(type(o))
    (RESULTS_DIR / f"level_{level}_results.json").write_text(
        json.dumps(payload, indent=2, default=conv, ensure_ascii=False), encoding="utf-8")


def pct(x, digits=2):
    return f"{x:.{digits}f}%"
